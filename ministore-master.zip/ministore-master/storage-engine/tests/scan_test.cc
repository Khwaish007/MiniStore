#include <cassert>
#include <cstdio>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>

#include "engine.h"

namespace fs = std::filesystem;

int main() {
  fs::path dir = fs::temp_directory_path() / "ministore_scan_test";
  fs::remove_all(dir);

  ministore::Engine engine(dir.string(), /*memtable_flush_bytes=*/64);

  for (int i = 0; i < 50; ++i) {
    char buf[16];
    std::snprintf(buf, sizeof(buf), "k%03d", i);  // zero-padded: lexicographic order == numeric order
    engine.Put(buf, "v" + std::to_string(i));
  }
  engine.Delete("k010");
  engine.Put("k020", "updated20");

  // Force a compaction so the scan below exercises both a compacted
  // SSTable and whatever's left in the live memtable, not just one or the
  // other, then add one more write after compaction to prove the merge
  // picks up the memtable's current state too.
  engine.TriggerCompactionForTest();
  engine.Put("kzzz_after_compaction", "late");

  std::vector<std::pair<std::string, std::string>> results;
  bool ok = engine.Scan("k010", "k030", [&](const std::string& k, const std::string& v) {
    results.emplace_back(k, v);
  });
  assert(ok);

  // [k010, k030): k010 is tombstoned so it must not appear, leaving
  // k011..k029 (19 keys).
  assert(results.size() == 19);
  assert(results.front().first == "k011");
  assert(results.back().first == "k029");
  for (auto& kv : results) {
    if (kv.first == "k020") assert(kv.second == "updated20");
  }

  // Unbounded scan must include the post-compaction memtable write.
  std::vector<std::pair<std::string, std::string>> full;
  engine.Scan("", "", [&](const std::string& k, const std::string& v) {
    full.emplace_back(k, v);
  });
  bool found_late = false;
  for (auto& kv : full) {
    if (kv.first == "kzzz_after_compaction") {
      found_late = true;
      assert(kv.second == "late");
    }
  }
  assert(found_late);

  // Results must come back in ascending key order.
  for (size_t i = 1; i < full.size(); ++i) {
    assert(full[i - 1].first < full[i].first);
  }

  fs::remove_all(dir);
  std::cout << "scan_test: all assertions passed\n";
  return 0;
}
