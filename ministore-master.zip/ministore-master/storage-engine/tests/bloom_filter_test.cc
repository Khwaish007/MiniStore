#include <cassert>
#include <iostream>
#include <random>
#include <string>
#include <unordered_set>
#include <vector>

#include "bloom_filter.h"

int main() {
  using ministore::BloomFilter;

  // Zero false negatives: every key that was Add()-ed must MightContain().
  {
    std::vector<std::string> keys;
    for (int i = 0; i < 5000; ++i) {
      keys.push_back("key-" + std::to_string(i));
    }

    BloomFilter bloom = BloomFilter::ForExpectedKeys(keys.size());
    for (const auto& k : keys) bloom.Add(k);
    for (const auto& k : keys) {
      assert(bloom.MightContain(k));
    }
  }

  // False-positive rate stays within a reasonable band of the ~1% target
  // for 10 bits/key at k=7 (checked loosely -- this is a statistical
  // property, not an exact one).
  {
    std::unordered_set<std::string> present;
    BloomFilter bloom = BloomFilter::ForExpectedKeys(10000);
    for (int i = 0; i < 10000; ++i) {
      std::string k = "present-" + std::to_string(i);
      present.insert(k);
      bloom.Add(k);
    }

    int false_positives = 0;
    int trials = 20000;
    for (int i = 0; i < trials; ++i) {
      std::string k = "absent-" + std::to_string(i);
      assert(present.find(k) == present.end());
      if (bloom.MightContain(k)) ++false_positives;
    }

    double fp_rate = static_cast<double>(false_positives) / trials;
    std::cout << "observed false-positive rate: " << fp_rate << "\n";
    assert(fp_rate < 0.03);  // generous upper bound around the ~1% target
  }

  // Serialize/deserialize round-trip preserves lookup behavior.
  {
    BloomFilter bloom = BloomFilter::ForExpectedKeys(100);
    bloom.Add("round-trip-key");
    BloomFilter restored = BloomFilter::FromBytes(bloom.bytes(), bloom.num_hashes());
    assert(restored.MightContain("round-trip-key"));
  }

  // Empty filter (no bytes loaded) fails open rather than false-negative.
  {
    BloomFilter empty = BloomFilter::FromBytes("", 7);
    assert(empty.MightContain("anything"));
  }

  std::cout << "bloom_filter_test: all assertions passed\n";
  return 0;
}
