#include <atomic>
#include <cassert>
#include <filesystem>
#include <iostream>
#include <string>
#include <thread>

#include "engine.h"

namespace fs = std::filesystem;

int main() {
  fs::path dir = fs::temp_directory_path() / "ministore_compaction_test";
  fs::remove_all(dir);

  // Tiny flush threshold forces many memtable -> SSTable flushes, so we
  // accumulate several tables to compact.
  ministore::Engine engine(dir.string(), /*memtable_flush_bytes=*/64);

  for (int i = 0; i < 100; ++i) {
    engine.Put("k" + std::to_string(i), "v" + std::to_string(i));
  }
  // Overwrite some keys (later value should win) and delete others
  // (tombstone should make them disappear entirely after compaction).
  for (int i = 0; i < 20; ++i) {
    engine.Put("k" + std::to_string(i), "updated" + std::to_string(i));
  }
  for (int i = 20; i < 40; ++i) {
    engine.Delete("k" + std::to_string(i));
  }
  // Force everything out of the memtable first so Stats() is exact right
  // after compaction, instead of also reflecting whatever happened to be
  // sitting unflushed (Stats()'s documented approximation is specifically
  // about that gap, not about compaction itself).
  engine.FlushForTest();

  // A concurrent reader hammering Get() during the forced compaction pass
  // below must never crash or see a torn/invalid read.
  std::atomic<bool> stop{false};
  std::atomic<int> reads{0};
  std::thread reader([&] {
    std::string value;
    while (!stop.load()) {
      for (int i = 0; i < 100; ++i) {
        engine.Get("k" + std::to_string(i), &value);
      }
      reads.fetch_add(1);
    }
  });

  engine.TriggerCompactionForTest();

  stop.store(true);
  reader.join();
  assert(reads.load() > 0);

  std::string value;
  for (int i = 0; i < 20; ++i) {
    assert(engine.Get("k" + std::to_string(i), &value));
    assert(value == "updated" + std::to_string(i));
  }
  for (int i = 20; i < 40; ++i) {
    assert(!engine.Get("k" + std::to_string(i), &value));
  }
  for (int i = 40; i < 100; ++i) {
    assert(engine.Get("k" + std::to_string(i), &value));
    assert(value == "v" + std::to_string(i));
  }

  auto stats = engine.Stats();
  // 100 keys - 20 deleted = 80 live keys, all folded into the compacted
  // table by the forced pass above (compaction always covers everything
  // live, per CompactAll's contract).
  assert(stats.key_count == 80);

  // Compaction should have collapsed many small SSTables into one file,
  // with the superseded ones removed from disk.
  int sst_count = 0;
  for (const auto& entry : fs::directory_iterator(dir)) {
    if (entry.path().extension() == ".sst") ++sst_count;
  }
  assert(sst_count == 1);

  fs::remove_all(dir);
  std::cout << "compaction_test: all assertions passed\n";
  return 0;
}
