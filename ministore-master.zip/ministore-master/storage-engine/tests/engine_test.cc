#include <cassert>
#include <filesystem>
#include <iostream>
#include <string>

#include "engine.h"

namespace fs = std::filesystem;

int main() {
  fs::path dir = fs::temp_directory_path() / "ministore_engine_test";
  fs::remove_all(dir);

  {
    // Tiny flush threshold forces multiple memtable -> SSTable flushes
    // during this test, so we're exercising the flush + multi-SSTable read
    // path, not just the memtable.
    ministore::Engine engine(dir.string(), /*memtable_flush_bytes=*/64);

    assert(engine.Put("a", "1"));
    assert(engine.Put("b", "2"));
    assert(engine.Put("c", "3"));

    std::string value;
    assert(engine.Get("a", &value) && value == "1");
    assert(engine.Get("b", &value) && value == "2");
    assert(!engine.Get("z", &value));

    assert(engine.Delete("b"));
    assert(!engine.Get("b", &value));

    for (int i = 0; i < 20; ++i) {
      engine.Put("bulk" + std::to_string(i), std::string(20, 'x'));
    }
    assert(engine.Get("bulk5", &value) && value == std::string(20, 'x'));
  }

  {
    // Fresh Engine over the same data_dir simulates a restart: verifies
    // WAL replay + SSTable recovery reconstruct the exact same state,
    // including the tombstone surviving across the flush boundary.
    ministore::Engine engine(dir.string());
    std::string value;
    assert(engine.Get("a", &value) && value == "1");
    assert(engine.Get("c", &value) && value == "3");
    assert(!engine.Get("b", &value));
    assert(engine.Get("bulk5", &value));
    assert(!engine.Get("nonexistent", &value));
  }

  fs::remove_all(dir);
  std::cout << "engine_test: all assertions passed\n";
  return 0;
}
