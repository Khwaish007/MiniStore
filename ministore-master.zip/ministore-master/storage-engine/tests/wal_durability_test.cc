#include <cassert>
#include <filesystem>
#include <iostream>
#include <map>
#include <string>

#include "wal.h"

namespace fs = std::filesystem;

int main() {
  fs::path path = fs::temp_directory_path() / "ministore_wal_durability_test.log";
  fs::remove(path);

  {
    ministore::Wal wal(path.string());
    assert(wal.AppendPut("a", "1"));
    assert(wal.AppendPut("b", "2"));
    assert(wal.AppendDelete("a"));
    assert(wal.AppendPut("c", "3"));
  }

  // Every AppendPut/AppendDelete above calls fsync(2) before returning
  // (see Wal::WriteRecord/Sync), so by the time this test reopens the
  // file, the bytes were handed to the kernel with a durability request
  // per record -- stronger than the previous ofstream::flush()-only
  // behavior, which only guaranteed the OS page cache. What this
  // in-process test genuinely cannot prove is survival across an actual
  // power loss; that would require killing the process/VM mid-write and
  // inspecting the file from the outside, out of scope here. This test is
  // scoped to what it can actually assert: a fresh reopen sees exactly
  // the replayed state the writes implied.
  std::map<std::string, std::string> replayed;
  bool deleted_a = false;
  {
    ministore::Wal wal(path.string());
    bool ok = wal.Replay(
        [&](const std::string& k, const std::string& v) { replayed[k] = v; },
        [&](const std::string& k) {
          replayed.erase(k);
          if (k == "a") deleted_a = true;
        });
    assert(ok);
  }

  assert(deleted_a);
  assert(replayed.count("a") == 0);
  assert(replayed.at("b") == "2");
  assert(replayed.at("c") == "3");

  fs::remove(path);
  std::cout << "wal_durability_test: all assertions passed\n";
  return 0;
}
