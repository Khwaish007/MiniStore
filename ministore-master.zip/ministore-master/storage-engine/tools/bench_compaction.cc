// bench_compaction drives the SSTable/compaction layer directly (not
// through Engine, so nothing here is affected by Engine's own automatic
// compaction trigger) to produce two numbers:
//
//   1. Point-lookup latency across N accumulated SSTables vs. the single
//      table CompactAll merges them into.
//   2. Missing-key lookup latency with the Bloom filter active
//      (SSTableReader::Get) vs. what every miss would cost without one --
//      simulated via NewIterator(key), which does the same sparse-index
//      seek-and-scan Get() falls back to on a possible match, but skips
//      straight to it instead of taking the MightContain() shortcut.
//
// Not a unit test: no assertions beyond internal consistency checks,
// meant to be run manually and its output pasted into docs/DESIGN.md.
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <iostream>
#include <memory>
#include <random>
#include <string>
#include <vector>

#include "compaction.h"
#include "sstable.h"

namespace fs = std::filesystem;
using ministore::CompactAll;
using ministore::SSTableReader;
using ministore::SSTableWriter;
using ministore::SSTRecord;

namespace {

std::string Key(int i) {
  char buf[16];
  std::snprintf(buf, sizeof(buf), "key%08d", i);
  return buf;
}

double ElapsedMicros(std::chrono::steady_clock::time_point start,
                      std::chrono::steady_clock::time_point end) {
  return std::chrono::duration<double, std::micro>(end - start).count();
}

struct LatencyStats {
  double total_micros = 0;
  int count = 0;
  double AvgMicros() const { return count == 0 ? 0 : total_micros / count; }
};

// Builds `num_tables` non-overlapping SSTables (key i lives in table
// i / keys_per_table), matching how flush-produced SSTables accumulate in
// a real engine before compaction runs.
std::vector<std::shared_ptr<SSTableReader>> BuildSyntheticTables(const std::string& dir,
                                                                   int num_tables,
                                                                   int keys_per_table) {
  std::vector<std::shared_ptr<SSTableReader>> tables;
  for (int t = 0; t < num_tables; ++t) {
    std::vector<std::pair<std::string, SSTRecord>> entries;
    entries.reserve(keys_per_table);
    for (int i = 0; i < keys_per_table; ++i) {
      int global_key = t * keys_per_table + i;
      entries.emplace_back(Key(global_key),
                            SSTRecord{"value" + std::to_string(global_key), false});
    }
    std::string path = dir + "/table" + std::to_string(t) + ".sst";
    SSTableWriter(path).Write(entries);
    tables.push_back(std::make_shared<SSTableReader>(path));
  }
  return tables;
}

// Mirrors Engine::Get's SSTable fallback loop: newest-to-oldest, first
// match wins. This is the exact "N accumulated tables" cost profile.
bool GetAcrossTables(const std::vector<std::shared_ptr<SSTableReader>>& tables,
                      const std::string& key, std::string* value_out) {
  bool deleted = false;
  for (auto it = tables.rbegin(); it != tables.rend(); ++it) {
    if ((*it)->Get(key, value_out, &deleted)) return !deleted;
  }
  return false;
}

}  // namespace

int main() {
  fs::path dir = fs::temp_directory_path() / "ministore_bench_compaction";
  fs::remove_all(dir);
  fs::create_directories(dir);

  constexpr int kNumTables = 20;
  constexpr int kKeysPerTable = 2000;  // 40,000 keys total
  constexpr int kLookups = 5000;
  const int kTotalKeys = kNumTables * kKeysPerTable;

  std::cout << "=== Benchmark 1: Get latency vs SSTable count (before vs after compaction) ===\n";
  std::cout << "tables=" << kNumTables << " keys/table=" << kKeysPerTable
            << " total_keys=" << kTotalKeys << " lookups=" << kLookups << "\n\n";

  auto tables = BuildSyntheticTables(dir.string(), kNumTables, kKeysPerTable);

  std::mt19937 rng(42);
  std::uniform_int_distribution<int> present_key_dist(0, kTotalKeys - 1);

  LatencyStats before_present;
  {
    std::string value;
    for (int i = 0; i < kLookups; ++i) {
      std::string key = Key(present_key_dist(rng));
      auto start = std::chrono::steady_clock::now();
      bool found = GetAcrossTables(tables, key, &value);
      auto end = std::chrono::steady_clock::now();
      if (!found) {
        std::cerr << "unexpected miss for " << key << "\n";
        return 1;
      }
      before_present.total_micros += ElapsedMicros(start, end);
      ++before_present.count;
    }
  }
  std::cout << "BEFORE compaction (" << kNumTables
            << " tables), present-key Get: avg=" << before_present.AvgMicros() << " us\n";

  std::string compacted_path = (dir / "compacted.sst").string();
  auto compact_start = std::chrono::steady_clock::now();
  bool ok = CompactAll(tables, compacted_path);
  auto compact_end = std::chrono::steady_clock::now();
  if (!ok) {
    std::cerr << "compaction failed\n";
    return 1;
  }
  std::cout << "Compaction of " << kNumTables << " tables (" << kTotalKeys << " keys) took "
            << ElapsedMicros(compact_start, compact_end) / 1000.0 << " ms\n";

  auto compacted = std::make_shared<SSTableReader>(compacted_path);
  std::vector<std::shared_ptr<SSTableReader>> single_table{compacted};

  LatencyStats after_present;
  {
    std::string value;
    for (int i = 0; i < kLookups; ++i) {
      std::string key = Key(present_key_dist(rng));
      auto start = std::chrono::steady_clock::now();
      bool found = GetAcrossTables(single_table, key, &value);
      auto end = std::chrono::steady_clock::now();
      if (!found) {
        std::cerr << "unexpected miss for " << key << " after compaction\n";
        return 1;
      }
      after_present.total_micros += ElapsedMicros(start, end);
      ++after_present.count;
    }
  }
  std::cout << "AFTER compaction (1 table), present-key Get: avg=" << after_present.AvgMicros()
            << " us\n";
  std::cout << "Speedup: " << (before_present.AvgMicros() / after_present.AvgMicros()) << "x\n\n";

  std::cout << "=== Benchmark 2: Bloom filter effect on missing-key lookups ===\n";
  std::cout << "Comparing SSTableReader::Get() (bloom filter active) against a raw\n"
               "index-seek-and-scan via NewIterator(key) (what every miss would cost\n"
               "without a bloom filter), across the same "
            << kNumTables << " accumulated tables.\n\n";

  std::uniform_int_distribution<int> missing_key_dist(kTotalKeys, kTotalKeys * 2 - 1);

  LatencyStats with_bloom;
  {
    std::string value;
    bool deleted;
    for (int i = 0; i < kLookups; ++i) {
      std::string key = Key(missing_key_dist(rng));
      auto start = std::chrono::steady_clock::now();
      for (auto it = tables.rbegin(); it != tables.rend(); ++it) {
        (*it)->Get(key, &value, &deleted);
      }
      auto end = std::chrono::steady_clock::now();
      with_bloom.total_micros += ElapsedMicros(start, end);
      ++with_bloom.count;
    }
  }
  std::cout << "WITH bloom filter, missing-key lookup across " << kNumTables
            << " tables: avg=" << with_bloom.AvgMicros() << " us\n";

  LatencyStats without_bloom;
  {
    for (int i = 0; i < kLookups; ++i) {
      std::string key = Key(missing_key_dist(rng));
      auto start = std::chrono::steady_clock::now();
      for (auto it = tables.rbegin(); it != tables.rend(); ++it) {
        auto iter = (*it)->NewIterator(key);
        bool found = iter.Valid() && iter.key() == key;
        (void)found;
      }
      auto end = std::chrono::steady_clock::now();
      without_bloom.total_micros += ElapsedMicros(start, end);
      ++without_bloom.count;
    }
  }
  std::cout << "WITHOUT bloom filter (raw index seek+scan), missing-key lookup across "
            << kNumTables << " tables: avg=" << without_bloom.AvgMicros() << " us\n";
  std::cout << "Speedup from bloom filter on misses: "
            << (without_bloom.AvgMicros() / with_bloom.AvgMicros()) << "x\n";

  fs::remove_all(dir);
  return 0;
}
