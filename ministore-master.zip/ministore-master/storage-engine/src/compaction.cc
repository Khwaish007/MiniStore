#include "compaction.h"

#include <algorithm>
#include <utility>

namespace ministore {

namespace {

struct HeapEntry {
  std::string key;
  size_t rank;  // index into the input `tables` vector; higher = newer
  std::unique_ptr<SSTableReader::Iterator> iter;
};

// Ordered so the *smallest* key sorts to heap.front() under
// std::make_heap/push_heap/pop_heap (which otherwise produce a max-heap):
// this comparator reports a as "less than" b whenever a's key is larger,
// so the element the algorithm treats as the "maximum" is the one with
// the smallest key.
bool HeapLess(const HeapEntry& a, const HeapEntry& b) { return a.key > b.key; }

}  // namespace

bool CompactAll(const std::vector<std::shared_ptr<SSTableReader>>& tables,
                 const std::string& out_path) {
  std::vector<HeapEntry> heap;
  heap.reserve(tables.size());
  for (size_t rank = 0; rank < tables.size(); ++rank) {
    auto iter = std::make_unique<SSTableReader::Iterator>(tables[rank]->NewIterator());
    if (iter->Valid()) {
      HeapEntry e{iter->key(), rank, std::move(iter)};
      heap.push_back(std::move(e));
    }
  }
  std::make_heap(heap.begin(), heap.end(), HeapLess);

  std::vector<std::pair<std::string, SSTRecord>> merged;

  while (!heap.empty()) {
    std::pop_heap(heap.begin(), heap.end(), HeapLess);
    HeapEntry top = std::move(heap.back());
    heap.pop_back();

    const std::string key = top.key;
    size_t best_rank = top.rank;
    SSTRecord best_record = top.iter->record();

    std::vector<HeapEntry> same_key;
    same_key.push_back(std::move(top));

    // Every other source currently sitting on the same key must be
    // advanced too (deduped), and the newest-ranked one wins.
    while (!heap.empty() && heap.front().key == key) {
      std::pop_heap(heap.begin(), heap.end(), HeapLess);
      HeapEntry e = std::move(heap.back());
      heap.pop_back();
      if (e.rank > best_rank) {
        best_rank = e.rank;
        best_record = e.iter->record();
      }
      same_key.push_back(std::move(e));
    }

    if (!best_record.deleted) {
      merged.emplace_back(key, std::move(best_record));
    }
    // A winning tombstone is simply not emitted -- real garbage collection,
    // valid only because `tables` covers everything currently live.

    for (auto& e : same_key) {
      e.iter->Next();
      if (e.iter->Valid()) {
        HeapEntry next{e.iter->key(), e.rank, std::move(e.iter)};
        heap.push_back(std::move(next));
        std::push_heap(heap.begin(), heap.end(), HeapLess);
      }
    }
  }

  SSTableWriter writer(out_path);
  return writer.Write(merged);
}

}  // namespace ministore
