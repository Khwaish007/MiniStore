#pragma once

#include <memory>
#include <string>
#include <vector>

#include "sstable.h"

namespace ministore {

// K-way merges every given (already-sorted, immutable) SSTable into a
// single new SSTable at out_path: dedupes keys (the table with the
// highest index in `tables` wins -- callers must pass tables ordered
// oldest-to-newest, matching Engine's sstables_ ordering) and drops
// tombstones outright.
//
// Dropping tombstones unconditionally is only correct because this always
// compacts *every* currently-live table together -- there is by
// definition nothing older left underneath a winning tombstone to still
// need shadowing. A partial/leveled compaction would not get to make this
// simplification.
bool CompactAll(const std::vector<std::shared_ptr<SSTableReader>>& tables,
                 const std::string& out_path);

}  // namespace ministore
