#include <grpcpp/grpcpp.h>

#include <chrono>
#include <iostream>
#include <memory>
#include <string>
#include <thread>

#include "control.grpc.pb.h"
#include "engine.h"
#include "storage.grpc.pb.h"

namespace {

// Keys are namespaced by tenant at the RPC boundary (tenant_id + '\0' +
// key) so the single-node Engine stays tenant-agnostic; per-tenant billing
// is metered by the control plane, which sees every routed request.
std::string TenantKey(const std::string& tenant_id, const std::string& key) {
  std::string composite;
  composite.reserve(tenant_id.size() + 1 + key.size());
  composite.append(tenant_id);
  composite.push_back('\0');
  composite.append(key);
  return composite;
}

class StorageServiceImpl final : public ministore::storage::StorageService::Service {
 public:
  explicit StorageServiceImpl(ministore::Engine* engine) : engine_(engine) {}

  grpc::Status Put(grpc::ServerContext*, const ministore::storage::PutRequest* request,
                    ministore::storage::PutResponse* response) override {
    response->set_ok(
        engine_->Put(TenantKey(request->tenant_id(), request->key()), request->value()));
    return grpc::Status::OK;
  }

  grpc::Status Get(grpc::ServerContext*, const ministore::storage::GetRequest* request,
                    ministore::storage::GetResponse* response) override {
    std::string value;
    bool found = engine_->Get(TenantKey(request->tenant_id(), request->key()), &value);
    response->set_found(found);
    if (found) response->set_value(value);
    return grpc::Status::OK;
  }

  grpc::Status Delete(grpc::ServerContext*, const ministore::storage::DeleteRequest* request,
                       ministore::storage::DeleteResponse* response) override {
    response->set_ok(engine_->Delete(TenantKey(request->tenant_id(), request->key())));
    return grpc::Status::OK;
  }

  grpc::Status Scan(grpc::ServerContext*, const ministore::storage::ScanRequest* request,
                     grpc::ServerWriter<ministore::storage::ScanEntry>* writer) override {
    const std::string& tenant_id = request->tenant_id();
    std::string start = TenantKey(tenant_id, request->start_key());
    // An empty end_key means "to the end of the keyspace" at the Engine
    // level, but at this tenant-namespacing boundary that must not be
    // taken literally -- it would spill into whichever tenant happens to
    // sort right after this one. tenant_id + '\x01' is the correct
    // exclusive upper bound: every composite key for this tenant is
    // tenant_id + '\0' + ..., and '\0' < '\x01' at that fixed position
    // regardless of what follows, so this bound always includes exactly
    // this tenant's full range and nothing past it.
    std::string end = request->end_key().empty() ? tenant_id + '\x01'
                                                   : TenantKey(tenant_id, request->end_key());
    size_t prefix_len = tenant_id.size() + 1;

    engine_->Scan(start, end, [&](const std::string& composite_key, const std::string& value) {
      ministore::storage::ScanEntry entry;
      entry.set_key(composite_key.substr(prefix_len));
      entry.set_value(value);
      writer->Write(entry);
    });
    return grpc::Status::OK;
  }

  grpc::Status Stats(grpc::ServerContext*, const ministore::storage::StatsRequest*,
                      ministore::storage::StatsResponse* response) override {
    auto stats = engine_->Stats();
    response->set_key_count(stats.key_count);
    response->set_bytes_stored(stats.bytes_stored);
    response->set_read_ops(stats.read_ops);
    response->set_write_ops(stats.write_ops);
    return grpc::Status::OK;
  }

 private:
  ministore::Engine* engine_;
};

// A bind address like "0.0.0.0:9090" is only meaningful as something to
// *listen on* -- it isn't a connectable address, so it must not be what
// gets registered with the control plane. Absent an explicit
// --advertise-addr, substitute "localhost" for a wildcard host.
std::string DefaultAdvertiseAddr(const std::string& listen_addr) {
  auto colon = listen_addr.find(':');
  if (colon != std::string::npos) {
    std::string host = listen_addr.substr(0, colon);
    if (host.empty() || host == "0.0.0.0") {
      return "localhost" + listen_addr.substr(colon);
    }
  }
  return listen_addr;
}

// Registers with the control plane, retrying with exponential backoff so
// a storage node started before the control plane (or with it briefly
// down) doesn't just give up -- if every attempt fails, this returns
// false and the node keeps serving standalone, since the data plane
// doesn't actually need the control plane to function for direct callers.
bool RegisterWithRetry(const std::string& control_plane_addr, const std::string& node_id,
                        const std::string& advertise_addr) {
  auto channel = grpc::CreateChannel(control_plane_addr, grpc::InsecureChannelCredentials());
  auto stub = ministore::control::ControlService::NewStub(channel);

  constexpr int kMaxAttempts = 5;
  auto delay = std::chrono::milliseconds(500);
  for (int attempt = 1; attempt <= kMaxAttempts; ++attempt) {
    ministore::control::RegisterNodeRequest request;
    request.set_node_id(node_id);
    request.set_address(advertise_addr);
    ministore::control::RegisterNodeResponse response;

    grpc::ClientContext context;
    context.set_deadline(std::chrono::system_clock::now() + std::chrono::seconds(3));
    grpc::Status status = stub->RegisterNode(&context, request, &response);
    if (status.ok() && response.ok()) {
      std::cout << "registered with control plane at " << control_plane_addr << " as node "
                << node_id << "\n";
      return true;
    }

    std::cerr << "control plane registration attempt " << attempt << "/" << kMaxAttempts
              << " failed (" << status.error_message() << "), retrying in " << delay.count()
              << "ms\n";
    if (attempt < kMaxAttempts) std::this_thread::sleep_for(delay);
    delay *= 2;
  }
  std::cerr << "could not reach control plane after " << kMaxAttempts
            << " attempts -- continuing to serve standalone\n";
  return false;
}

void HeartbeatLoop(ministore::Engine* engine, const std::string& control_plane_addr,
                    const std::string& node_id, std::chrono::seconds interval) {
  auto channel = grpc::CreateChannel(control_plane_addr, grpc::InsecureChannelCredentials());
  auto stub = ministore::control::ControlService::NewStub(channel);

  while (true) {
    std::this_thread::sleep_for(interval);

    auto stats = engine->Stats();
    ministore::control::HeartbeatRequest request;
    request.set_node_id(node_id);
    request.set_key_count(stats.key_count);
    request.set_bytes_stored(stats.bytes_stored);
    ministore::control::HeartbeatResponse response;

    grpc::ClientContext context;
    context.set_deadline(std::chrono::system_clock::now() + std::chrono::seconds(3));
    grpc::Status status = stub->Heartbeat(&context, request, &response);
    if (!status.ok() || !response.ok()) {
      std::cerr << "heartbeat to control plane failed: " << status.error_message() << "\n";
    }
  }
}

}  // namespace

int main(int argc, char** argv) {
  std::string data_dir = argc > 1 ? argv[1] : "./data";
  std::string listen_addr = argc > 2 ? argv[2] : "0.0.0.0:9090";
  std::string control_plane_addr = "localhost:8080";
  std::string node_id;
  std::string advertise_addr;

  for (int i = 3; i < argc; ++i) {
    std::string arg = argv[i];
    auto value = [&]() -> std::string {
      auto eq = arg.find('=');
      if (eq != std::string::npos) return arg.substr(eq + 1);
      return (i + 1 < argc) ? argv[++i] : std::string();
    };
    if (arg.rfind("--control-plane-addr", 0) == 0) {
      control_plane_addr = value();
    } else if (arg.rfind("--node-id", 0) == 0) {
      node_id = value();
    } else if (arg.rfind("--advertise-addr", 0) == 0) {
      advertise_addr = value();
    }
  }
  if (node_id.empty()) node_id = listen_addr;
  if (advertise_addr.empty()) advertise_addr = DefaultAdvertiseAddr(listen_addr);

  ministore::Engine engine(data_dir);
  StorageServiceImpl service(&engine);

  grpc::ServerBuilder builder;
  builder.AddListeningPort(listen_addr, grpc::InsecureServerCredentials());
  builder.RegisterService(&service);

  std::unique_ptr<grpc::Server> server(builder.BuildAndStart());
  std::cout << "ministore storage node listening on " << listen_addr << " (data dir: " << data_dir
            << ")\n";

  std::thread heartbeat_thread;
  if (RegisterWithRetry(control_plane_addr, node_id, advertise_addr)) {
    heartbeat_thread =
        std::thread(HeartbeatLoop, &engine, control_plane_addr, node_id, std::chrono::seconds(5));
  }

  server->Wait();
  if (heartbeat_thread.joinable()) heartbeat_thread.join();
  return 0;
}
