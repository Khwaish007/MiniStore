#include <iostream>
#include <sstream>

#include "engine.h"

// storage_cli is a local debug REPL for the Engine, independent of gRPC --
// it builds and runs today even before protobuf/gRPC are installed.
int main(int argc, char** argv) {
  std::string data_dir = argc > 1 ? argv[1] : "./data";
  ministore::Engine engine(data_dir);

  std::cout << "ministore storage engine CLI  (data dir: " << data_dir << ")\n"
            << "commands: put <key> <value> | get <key> | del <key> | stats | quit\n";

  std::string line;
  while (std::cout << "> " && std::getline(std::cin, line)) {
    std::istringstream iss(line);
    std::string cmd;
    iss >> cmd;

    if (cmd == "put") {
      std::string key, value;
      iss >> key;
      std::getline(iss, value);
      if (!value.empty() && value[0] == ' ') value.erase(0, 1);
      std::cout << (engine.Put(key, value) ? "OK\n" : "ERROR\n");
    } else if (cmd == "get") {
      std::string key;
      iss >> key;
      std::string value;
      if (engine.Get(key, &value)) {
        std::cout << value << "\n";
      } else {
        std::cout << "(not found)\n";
      }
    } else if (cmd == "del") {
      std::string key;
      iss >> key;
      std::cout << (engine.Delete(key) ? "OK\n" : "ERROR\n");
    } else if (cmd == "stats") {
      auto stats = engine.Stats();
      std::cout << "keys(memtable)=" << stats.key_count
                << " bytes(memtable)=" << stats.bytes_stored
                << " reads=" << stats.read_ops << " writes=" << stats.write_ops << "\n";
    } else if (cmd == "quit" || cmd == "exit") {
      break;
    } else if (!cmd.empty()) {
      std::cout << "unknown command: " << cmd << "\n";
    }
  }
  return 0;
}
