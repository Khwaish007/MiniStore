#pragma once

#include <cstdint>
#include <string>

namespace ministore {

// A standard Bloom filter: MightContain() never false-negatives, and can
// false-positive at a rate governed by bits-per-key and hash count. Used by
// SSTableReader to skip the sparse-index search (and any disk seek) for
// keys that provably aren't in a given table.
//
// Sized at 10 bits/key with k=7 hash probes (~1% false-positive rate),
// deriving all k probe indices from two independent 64-bit FNV-1a hashes
// via the Kirsch-Mitzenmacher trick (h_i = h1 + i*h2), rather than
// implementing k distinct hash functions.
class BloomFilter {
 public:
  // Sized for `expected_keys` entries. Always allocates at least enough
  // bits to be usable even for a very small or empty table.
  static BloomFilter ForExpectedKeys(size_t expected_keys);

  // Reconstructs a filter from bytes previously returned by bytes().
  static BloomFilter FromBytes(std::string bytes, uint32_t num_hashes);

  void Add(const std::string& key);

  // Conservative on malformed/missing filter data: an empty filter always
  // returns true (fail open) rather than risk a false negative.
  bool MightContain(const std::string& key) const;

  const std::string& bytes() const { return bits_; }
  uint32_t num_hashes() const { return num_hashes_; }

 private:
  BloomFilter(std::string bits, uint32_t num_hashes)
      : bits_(std::move(bits)), num_hashes_(num_hashes) {}

  std::string bits_;  // bit-packed, 8 bits per byte
  uint32_t num_hashes_ = 0;
};

}  // namespace ministore
