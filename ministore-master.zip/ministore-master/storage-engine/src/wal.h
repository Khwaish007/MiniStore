#pragma once

#include <cstdint>
#include <functional>
#include <string>

namespace ministore {

enum class WalOp : uint8_t { kPut = 0, kDelete = 1 };

// Append-only write-ahead log using POSIX open/write/fsync directly (this
// targets Linux specifically; portability isn't a goal here) so every
// record is durable across a real power loss, not just a process crash --
// an ofstream's flush() only reaches the OS page cache, not disk.
// Replay() rebuilds the memtable from the log on startup.
class Wal {
 public:
  explicit Wal(const std::string& path);
  ~Wal();

  bool AppendPut(const std::string& key, const std::string& value);
  bool AppendDelete(const std::string& key);

  // Replays every record in file order, invoking on_put/on_delete for each.
  bool Replay(const std::function<void(const std::string&, const std::string&)>& on_put,
              const std::function<void(const std::string&)>& on_delete);

  // Truncates the log; called right after a successful memtable flush.
  bool Reset();

 private:
  bool WriteRecord(WalOp op, const std::string& key, const std::string& value);
  bool Sync();

  std::string path_;
  int fd_ = -1;
};

}  // namespace ministore
