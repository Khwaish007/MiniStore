#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "memtable.h"
#include "sstable.h"
#include "wal.h"

namespace ministore {

struct EngineStats {
  uint64_t key_count = 0;
  uint64_t bytes_stored = 0;
  uint64_t read_ops = 0;
  uint64_t write_ops = 0;
};

// Engine is the single-node LSM-lite storage core: writes are fsync'd to
// the WAL, then applied to the memtable; once the memtable crosses
// `memtable_flush_bytes` it's flushed to an immutable, sorted SSTable file
// and the WAL is truncated. Reads check the memtable first, then SSTables
// newest-flushed-first.
//
// Once `kCompactionTrigger` SSTables have accumulated, a background thread
// merges all of them into one via CompactAll (see compaction.h),
// deduplicating keys and dropping tombstones. The merge I/O runs with no
// lock held; `sstables_` holds shared_ptr<SSTableReader> specifically so a
// Get()/Scan() that already grabbed its own copies keeps reading valid,
// un-deleted files even if compaction swaps the list out from under it
// mid-read -- the only concurrency change compaction requires, no mutex
// upgrade needed.
//
// Thread-safe: every public method takes `mu_`. Keys are opaque byte
// strings; multi-tenancy is handled by the caller (the gRPC server)
// prefixing keys with a tenant id.
class Engine {
 public:
  explicit Engine(std::string data_dir, size_t memtable_flush_bytes = 4 * 1024 * 1024);
  ~Engine();

  Engine(const Engine&) = delete;
  Engine& operator=(const Engine&) = delete;

  bool Put(const std::string& key, const std::string& value);
  bool Delete(const std::string& key);
  // Returns true if the key exists (present and not tombstoned).
  bool Get(const std::string& key, std::string* value_out);

  // Invokes callback(key, value) for every live key in [start_key, end_key)
  // in ascending order; an empty end_key means unbounded (scan to the end
  // of the keyspace). Only briefly holds mu_ to snapshot the current
  // SSTable list and seek the memtable iterator -- the merge itself and
  // every callback invocation run with no lock held, so a long scan
  // doesn't serialize concurrent Put/Get calls.
  bool Scan(const std::string& start_key, const std::string& end_key,
            const std::function<void(const std::string&, const std::string&)>& callback);

  EngineStats Stats() const;

  // Forces a compaction pass on the background thread and blocks until it
  // completes, bypassing the normal kCompactionTrigger threshold. Test-only.
  void TriggerCompactionForTest();

  // Forces the current memtable to flush regardless of size, so Stats()
  // becomes exact immediately afterward (nothing left uncounted in a
  // not-yet-flushed memtable). No-op if the memtable is empty. Test-only.
  void FlushForTest();

 private:
  static constexpr size_t kCompactionTrigger = 4;

  bool MaybeFlush(bool force = false);  // caller must hold mu_
  std::string NextSSTablePath();

  void CompactionThreadMain();
  void RunCompactionPass(bool force);  // does its own locking of mu_ internally

  std::string data_dir_;
  size_t memtable_flush_bytes_;

  mutable std::mutex mu_;
  MemTable memtable_;
  std::unique_ptr<Wal> wal_;
  std::vector<std::shared_ptr<SSTableReader>> sstables_;  // oldest first, newest at back
  std::atomic<int> next_sstable_id_{0};

  uint64_t read_ops_ = 0;
  uint64_t write_ops_ = 0;
  // Exact for everything folded into the last compaction pass; the live
  // memtable and any tables flushed since are layered on top via
  // memtable_.Size()/ApproxBytes() in Stats(), which can double-count a
  // key that exists in both -- an intentional, documented approximation
  // rather than re-merging the whole dataset on every Stats() call.
  uint64_t compacted_key_count_ = 0;
  uint64_t compacted_bytes_ = 0;

  std::thread compaction_thread_;
  std::mutex compaction_mu_;
  std::condition_variable compaction_cv_;
  bool compaction_requested_ = false;
  bool compaction_force_ = false;
  bool stop_ = false;
  // TriggerCompactionForTest must wait for its *own* request to be
  // serviced, not just for "some" pass to finish -- an unrelated
  // auto-triggered pass already in flight could otherwise complete right
  // after the forced request is registered and be mistaken for it. Each
  // request claims a strictly increasing sequence number; a pass records
  // the highest request sequence pending when it started servicing.
  uint64_t compaction_request_seq_ = 0;
  uint64_t compaction_completed_seq_ = 0;
};

}  // namespace ministore
