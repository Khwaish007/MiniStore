#include "wal.h"

#include <fcntl.h>
#include <unistd.h>

#include <fstream>

namespace ministore {

namespace {
constexpr int kOpenFlags = O_RDWR | O_CREAT | O_APPEND;
constexpr mode_t kOpenMode = 0644;
}  // namespace

Wal::Wal(const std::string& path) : path_(path) {
  fd_ = ::open(path_.c_str(), kOpenFlags, kOpenMode);
}

Wal::~Wal() {
  if (fd_ >= 0) ::close(fd_);
}

bool Wal::Sync() { return fd_ >= 0 && ::fsync(fd_) == 0; }

bool Wal::WriteRecord(WalOp op, const std::string& key, const std::string& value) {
  if (fd_ < 0) return false;

  uint8_t op_byte = static_cast<uint8_t>(op);
  uint32_t key_len = static_cast<uint32_t>(key.size());
  uint32_t val_len = static_cast<uint32_t>(value.size());

  std::string buf;
  buf.reserve(sizeof(op_byte) + sizeof(key_len) + key.size() + sizeof(val_len) + value.size());
  buf.append(reinterpret_cast<const char*>(&op_byte), sizeof(op_byte));
  buf.append(reinterpret_cast<const char*>(&key_len), sizeof(key_len));
  buf.append(key);
  buf.append(reinterpret_cast<const char*>(&val_len), sizeof(val_len));
  buf.append(value);

  const char* data = buf.data();
  size_t remaining = buf.size();
  while (remaining > 0) {
    ssize_t n = ::write(fd_, data, remaining);
    if (n <= 0) return false;  // interrupted/short writes aren't retried: treated as a hard failure
    data += n;
    remaining -= static_cast<size_t>(n);
  }

  // fsync every record individually rather than batching (group-commit is
  // an explicit backlog item, not attempted here) -- correctness over
  // throughput for this pass.
  return Sync();
}

bool Wal::AppendPut(const std::string& key, const std::string& value) {
  return WriteRecord(WalOp::kPut, key, value);
}

bool Wal::AppendDelete(const std::string& key) {
  return WriteRecord(WalOp::kDelete, key, "");
}

bool Wal::Replay(const std::function<void(const std::string&, const std::string&)>& on_put,
                  const std::function<void(const std::string&)>& on_delete) {
  // Reads the file independently of the append fd via a plain ifstream --
  // simpler than seeking the POSIX fd around, and this only ever runs
  // once at startup before any concurrent writers exist.
  std::ifstream in(path_, std::ios::binary);
  if (!in.is_open()) return false;

  while (true) {
    uint8_t op_byte;
    if (!in.read(reinterpret_cast<char*>(&op_byte), sizeof(op_byte))) break;

    uint32_t key_len;
    if (!in.read(reinterpret_cast<char*>(&key_len), sizeof(key_len))) break;
    std::string key(key_len, '\0');
    if (key_len > 0 && !in.read(key.data(), key_len)) break;

    uint32_t val_len;
    if (!in.read(reinterpret_cast<char*>(&val_len), sizeof(val_len))) break;
    std::string value(val_len, '\0');
    if (val_len > 0 && !in.read(value.data(), val_len)) break;

    if (static_cast<WalOp>(op_byte) == WalOp::kPut) {
      on_put(key, value);
    } else {
      on_delete(key);
    }
  }
  return true;
}

bool Wal::Reset() {
  if (fd_ >= 0) ::close(fd_);
  fd_ = ::open(path_.c_str(), kOpenFlags | O_TRUNC, kOpenMode);
  return fd_ >= 0;
}

}  // namespace ministore
