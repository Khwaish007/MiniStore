#include "bloom_filter.h"

#include <algorithm>

namespace ministore {

namespace {

constexpr double kBitsPerKey = 10.0;
constexpr uint32_t kNumHashes = 7;
constexpr size_t kMinBits = 64;

// Two fixed seeds for FNV-1a give two independent-enough hashes to derive
// all k probe indices from via the Kirsch-Mitzenmacher combination below,
// without implementing k distinct hash functions.
constexpr uint64_t kSeed1 = 0xcbf29ce484222325ULL;  // FNV-1a 64 offset basis
constexpr uint64_t kSeed2 = 0x9e3779b97f4a7c15ULL;  // golden-ratio constant

uint64_t Fnv1a64(const std::string& data, uint64_t seed) {
  uint64_t hash = seed;
  for (unsigned char c : data) {
    hash ^= c;
    hash *= 0x100000001b3ULL;
  }
  return hash;
}

// MurmurHash3's fmix64 finalizer. Raw FNV-1a has weak avalanche in its low
// bits -- exactly the bits the modulo-indexing below is most sensitive to
// -- which was measured to inflate the false-positive rate several times
// over the theoretical target; this finalizing mix fixes that.
uint64_t Mix64(uint64_t x) {
  x ^= x >> 33;
  x *= 0xff51afd7ed558ccdULL;
  x ^= x >> 33;
  x *= 0xc4ceb9fe1a85ec53ULL;
  x ^= x >> 33;
  return x;
}

}  // namespace

BloomFilter BloomFilter::ForExpectedKeys(size_t expected_keys) {
  size_t num_bits = std::max<size_t>(kMinBits, static_cast<size_t>(expected_keys * kBitsPerKey));
  size_t num_bytes = (num_bits + 7) / 8;
  return BloomFilter(std::string(num_bytes, '\0'), kNumHashes);
}

BloomFilter BloomFilter::FromBytes(std::string bytes, uint32_t num_hashes) {
  return BloomFilter(std::move(bytes), num_hashes);
}

void BloomFilter::Add(const std::string& key) {
  if (bits_.empty()) return;
  size_t num_bits = bits_.size() * 8;
  uint64_t h1 = Mix64(Fnv1a64(key, kSeed1));
  uint64_t h2 = Mix64(Fnv1a64(key, kSeed2));
  for (uint32_t i = 0; i < num_hashes_; ++i) {
    size_t idx = static_cast<size_t>((h1 + static_cast<uint64_t>(i) * h2) % num_bits);
    bits_[idx / 8] |= static_cast<char>(1u << (idx % 8));
  }
}

bool BloomFilter::MightContain(const std::string& key) const {
  if (bits_.empty()) return true;  // no filter data: fail open
  size_t num_bits = bits_.size() * 8;
  uint64_t h1 = Mix64(Fnv1a64(key, kSeed1));
  uint64_t h2 = Mix64(Fnv1a64(key, kSeed2));
  for (uint32_t i = 0; i < num_hashes_; ++i) {
    size_t idx = static_cast<size_t>((h1 + static_cast<uint64_t>(i) * h2) % num_bits);
    if (!(bits_[idx / 8] & static_cast<char>(1u << (idx % 8)))) {
      return false;
    }
  }
  return true;
}

}  // namespace ministore
