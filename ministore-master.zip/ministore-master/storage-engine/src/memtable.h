#pragma once

#include <cstddef>
#include <map>
#include <string>

namespace ministore {

struct Record {
  std::string value;
  bool deleted = false;
};

// In-memory sorted write buffer backing the active memtable. Not
// thread-safe on its own -- Engine serializes access with its own mutex.
class MemTable {
 public:
  // Forward-only iterator over the sorted map, for merge iteration
  // alongside SSTableReader::Iterator (see merge_iterator.h).
  class Iterator {
   public:
    bool Valid() const { return it_ != end_; }
    void Next() { ++it_; }
    const std::string& key() const { return it_->first; }
    const Record& record() const { return it_->second; }

   private:
    friend class MemTable;
    Iterator(std::map<std::string, Record>::const_iterator it,
             std::map<std::string, Record>::const_iterator end)
        : it_(it), end_(end) {}

    std::map<std::string, Record>::const_iterator it_;
    std::map<std::string, Record>::const_iterator end_;
  };

  void Put(const std::string& key, const std::string& value);
  void Delete(const std::string& key);

  // Returns true if the key has an entry (present or tombstoned), so the
  // caller knows not to fall through to older SSTables. When true,
  // *deleted_out distinguishes a live value from a tombstone.
  bool Get(const std::string& key, std::string* value_out, bool* deleted_out) const;

  size_t ApproxBytes() const { return approx_bytes_; }
  size_t Size() const { return table_.size(); }
  const std::map<std::string, Record>& Entries() const { return table_; }
  void Clear();

  Iterator NewIterator() const { return Iterator(table_.begin(), table_.end()); }
  Iterator NewIterator(const std::string& start_key) const {
    return Iterator(table_.lower_bound(start_key), table_.end());
  }

 private:
  std::map<std::string, Record> table_;
  size_t approx_bytes_ = 0;
};

}  // namespace ministore
