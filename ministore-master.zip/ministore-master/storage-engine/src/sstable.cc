#include "sstable.h"

#include <algorithm>
#include <utility>

namespace ministore {

namespace {
constexpr uint32_t kTombstone = 0xFFFFFFFFu;
constexpr int64_t kFooterSize = 36;  // 8+8+4+8+8, see layout comment in sstable.h

void WriteU32(std::ofstream& out, uint32_t v) {
  out.write(reinterpret_cast<const char*>(&v), sizeof(v));
}
void WriteU64(std::ofstream& out, uint64_t v) {
  out.write(reinterpret_cast<const char*>(&v), sizeof(v));
}
bool ReadU32(std::istream& in, uint32_t* v) {
  return static_cast<bool>(in.read(reinterpret_cast<char*>(v), sizeof(*v)));
}
bool ReadU64(std::istream& in, uint64_t* v) {
  return static_cast<bool>(in.read(reinterpret_cast<char*>(v), sizeof(*v)));
}
}  // namespace

SSTableWriter::SSTableWriter(std::string path, uint32_t index_interval)
    : path_(std::move(path)), index_interval_(index_interval == 0 ? 1 : index_interval) {}

bool SSTableWriter::Write(const std::vector<std::pair<std::string, SSTRecord>>& entries) const {
  std::ofstream out(path_, std::ios::binary | std::ios::trunc);
  if (!out.is_open()) return false;

  BloomFilter bloom = BloomFilter::ForExpectedKeys(entries.size());

  std::vector<std::pair<std::string, uint64_t>> sparse_index;
  uint64_t offset = 0;

  for (size_t i = 0; i < entries.size(); ++i) {
    const auto& key = entries[i].first;
    const auto& rec = entries[i].second;

    // Bloom filter answers "does this table have any entry for key"
    // (present or tombstoned), matching Get()'s existing semantics, so
    // every key is added regardless of the tombstone flag.
    bloom.Add(key);

    if (i % index_interval_ == 0) {
      sparse_index.emplace_back(key, offset);
    }

    WriteU32(out, static_cast<uint32_t>(key.size()));
    out.write(key.data(), static_cast<std::streamsize>(key.size()));
    offset += sizeof(uint32_t) + key.size();

    if (rec.deleted) {
      WriteU32(out, kTombstone);
      offset += sizeof(uint32_t);
    } else {
      WriteU32(out, static_cast<uint32_t>(rec.value.size()));
      out.write(rec.value.data(), static_cast<std::streamsize>(rec.value.size()));
      offset += sizeof(uint32_t) + rec.value.size();
    }
  }

  uint64_t bloom_offset = offset;
  const std::string& bloom_bytes = bloom.bytes();
  out.write(bloom_bytes.data(), static_cast<std::streamsize>(bloom_bytes.size()));
  offset += bloom_bytes.size();

  uint64_t index_offset = offset;
  for (const auto& kv : sparse_index) {
    WriteU32(out, static_cast<uint32_t>(kv.first.size()));
    out.write(kv.first.data(), static_cast<std::streamsize>(kv.first.size()));
    WriteU64(out, kv.second);
  }

  WriteU64(out, bloom_offset);
  WriteU64(out, static_cast<uint64_t>(bloom_bytes.size()));
  WriteU32(out, bloom.num_hashes());
  WriteU64(out, index_offset);
  WriteU64(out, static_cast<uint64_t>(sparse_index.size()));

  out.flush();
  return out.good();
}

SSTableReader::SSTableReader(std::string path) : path_(std::move(path)) {
  valid_ = LoadIndex();
}

bool SSTableReader::LoadIndex() {
  std::ifstream in(path_, std::ios::binary);
  if (!in.is_open()) return false;

  in.seekg(0, std::ios::end);
  auto file_size = in.tellg();
  if (file_size < kFooterSize) return false;

  in.seekg(static_cast<std::streamoff>(static_cast<int64_t>(file_size) - kFooterSize));
  uint64_t bloom_offset = 0, bloom_size = 0, index_offset = 0, index_count = 0;
  uint32_t bloom_num_hashes = 0;
  if (!ReadU64(in, &bloom_offset)) return false;
  if (!ReadU64(in, &bloom_size)) return false;
  if (!ReadU32(in, &bloom_num_hashes)) return false;
  if (!ReadU64(in, &index_offset)) return false;
  if (!ReadU64(in, &index_count)) return false;

  data_end_ = bloom_offset;

  in.seekg(static_cast<std::streamoff>(bloom_offset));
  std::string bloom_bytes(bloom_size, '\0');
  if (bloom_size > 0 && !in.read(bloom_bytes.data(), static_cast<std::streamsize>(bloom_size))) {
    return false;
  }
  bloom_ = BloomFilter::FromBytes(std::move(bloom_bytes), bloom_num_hashes);

  in.seekg(static_cast<std::streamoff>(index_offset));
  index_.reserve(index_count);
  for (uint64_t i = 0; i < index_count; ++i) {
    uint32_t key_len = 0;
    if (!ReadU32(in, &key_len)) return false;
    std::string key(key_len, '\0');
    if (key_len > 0 && !in.read(key.data(), key_len)) return false;
    uint64_t off = 0;
    if (!ReadU64(in, &off)) return false;
    index_.push_back({std::move(key), off});
  }
  return true;
}

bool SSTableReader::Get(const std::string& key, std::string* value_out, bool* deleted_out) const {
  if (!valid_ || index_.empty()) return false;
  if (bloom_ && !bloom_->MightContain(key)) return false;

  // Largest sparse-index entry with key <= target key.
  auto it = std::upper_bound(
      index_.begin(), index_.end(), key,
      [](const std::string& k, const IndexEntry& e) { return k < e.key; });
  if (it == index_.begin()) return false;
  --it;

  std::ifstream in(path_, std::ios::binary);
  if (!in.is_open()) return false;
  in.seekg(static_cast<std::streamoff>(it->offset));

  // Scan forward from this checkpoint, strictly bounded by the data block's
  // end so we never read into the bloom/index blocks that follow it.
  while (static_cast<uint64_t>(in.tellg()) < data_end_) {
    uint32_t key_len = 0;
    if (!ReadU32(in, &key_len)) return false;
    std::string cur_key(key_len, '\0');
    if (key_len > 0 && !in.read(cur_key.data(), key_len)) return false;

    uint32_t val_len = 0;
    if (!ReadU32(in, &val_len)) return false;

    if (cur_key == key) {
      if (val_len == kTombstone) {
        *deleted_out = true;
        value_out->clear();
      } else {
        *deleted_out = false;
        value_out->resize(val_len);
        if (val_len > 0 && !in.read(value_out->data(), val_len)) return false;
      }
      return true;
    }

    if (cur_key > key) return false;  // sorted data block: we've passed it

    if (val_len != kTombstone) {
      in.seekg(val_len, std::ios::cur);
    }
  }
  return false;
}

SSTableReader::Iterator::Iterator(const std::string& path, uint64_t start_offset,
                                   uint64_t data_end)
    : in_(path, std::ios::binary), data_end_(data_end) {
  if (in_.is_open()) {
    in_.seekg(static_cast<std::streamoff>(start_offset));
    Advance();
  } else {
    valid_ = false;
  }
}

void SSTableReader::Iterator::Advance() {
  if (!in_.is_open() || static_cast<uint64_t>(in_.tellg()) >= data_end_) {
    valid_ = false;
    return;
  }

  uint32_t key_len = 0;
  if (!ReadU32(in_, &key_len)) {
    valid_ = false;
    return;
  }
  key_.assign(key_len, '\0');
  if (key_len > 0 && !in_.read(key_.data(), key_len)) {
    valid_ = false;
    return;
  }

  uint32_t val_len = 0;
  if (!ReadU32(in_, &val_len)) {
    valid_ = false;
    return;
  }
  if (val_len == kTombstone) {
    record_.deleted = true;
    record_.value.clear();
  } else {
    record_.deleted = false;
    record_.value.assign(val_len, '\0');
    if (val_len > 0 && !in_.read(record_.value.data(), val_len)) {
      valid_ = false;
      return;
    }
  }
  valid_ = true;
}

void SSTableReader::Iterator::Next() { Advance(); }

SSTableReader::Iterator SSTableReader::NewIterator() const {
  return Iterator(path_, 0, data_end_);
}

SSTableReader::Iterator SSTableReader::NewIterator(const std::string& start_key) const {
  if (index_.empty()) return Iterator(path_, data_end_, data_end_);  // immediately invalid

  auto it = std::upper_bound(
      index_.begin(), index_.end(), start_key,
      [](const std::string& k, const IndexEntry& e) { return k < e.key; });
  uint64_t seek_offset = (it == index_.begin()) ? 0 : (it - 1)->offset;

  Iterator iter(path_, seek_offset, data_end_);
  while (iter.Valid() && iter.key() < start_key) {
    iter.Next();
  }
  return iter;
}

}  // namespace ministore
