#pragma once

#include <cstdint>
#include <fstream>
#include <optional>
#include <string>
#include <vector>

#include "bloom_filter.h"

namespace ministore {

struct SSTRecord {
  std::string value;
  bool deleted = false;
};

// On-disk layout (all integers native-endian to the build platform):
//   data block:  repeated [uint32 keylen][key][uint32 vallen][value]
//                vallen == kTombstone marks a deleted key with no value bytes.
//   bloom block: raw bit-packed Bloom filter bytes (see bloom_filter.h).
//   index block: repeated [uint32 keylen][key][uint64 offset], one entry
//                every `index_interval` data records (sparse index).
//   footer:      [uint64 bloom_offset][uint64 bloom_size][uint32 bloom_num_hashes]
//                [uint64 index_offset][uint64 index_count]
//                (fixed 36 bytes, at EOF)
class SSTableWriter {
 public:
  explicit SSTableWriter(std::string path, uint32_t index_interval = 16);

  // entries must already be sorted by key (MemTable::Entries() guarantees this).
  bool Write(const std::vector<std::pair<std::string, SSTRecord>>& entries) const;

 private:
  std::string path_;
  uint32_t index_interval_;
};

// Immutable, sorted on-disk table produced by a memtable flush. Point
// lookups check the Bloom filter first, then (on a possible match)
// binary-search the sparse index and scan the bounded block between two
// index checkpoints.
class SSTableReader {
 public:
  // Forward-only iterator over the data block, for full scans (from offset
  // 0) or range scans (seeked to a start key). Used by compaction and by
  // Engine::Scan's merge iterator.
  class Iterator {
   public:
    bool Valid() const { return valid_; }
    void Next();
    const std::string& key() const { return key_; }
    const SSTRecord& record() const { return record_; }

   private:
    friend class SSTableReader;
    Iterator(const std::string& path, uint64_t start_offset, uint64_t data_end);
    void Advance();

    std::ifstream in_;
    uint64_t data_end_ = 0;
    bool valid_ = false;
    std::string key_;
    SSTRecord record_;
  };

  explicit SSTableReader(std::string path);

  bool Valid() const { return valid_; }
  const std::string& path() const { return path_; }

  // Returns true if the key has an entry in this table (present or
  // tombstoned) -- the caller must check *deleted_out before treating a
  // false return as "not found anywhere".
  bool Get(const std::string& key, std::string* value_out, bool* deleted_out) const;

  Iterator NewIterator() const;
  Iterator NewIterator(const std::string& start_key) const;

 private:
  struct IndexEntry {
    std::string key;
    uint64_t offset;
  };

  bool LoadIndex();

  std::string path_;
  bool valid_ = false;
  uint64_t data_end_ = 0;
  std::vector<IndexEntry> index_;
  std::optional<BloomFilter> bloom_;
};

}  // namespace ministore
