#include "merge_iterator.h"

#include <algorithm>
#include <utility>

namespace ministore {

namespace {

class MemTableSource final : public MergeSource {
 public:
  explicit MemTableSource(MemTable::Iterator it) : it_(std::move(it)) {}
  bool Valid() const override { return it_.Valid(); }
  void Next() override { it_.Next(); }
  const std::string& key() const override { return it_.key(); }
  SSTRecord record() const override {
    const Record& r = it_.record();
    return SSTRecord{r.value, r.deleted};
  }

 private:
  MemTable::Iterator it_;
};

class SSTableSource final : public MergeSource {
 public:
  explicit SSTableSource(SSTableReader::Iterator it) : it_(std::move(it)) {}
  bool Valid() const override { return it_.Valid(); }
  void Next() override { it_.Next(); }
  const std::string& key() const override { return it_.key(); }
  SSTRecord record() const override { return it_.record(); }

 private:
  SSTableReader::Iterator it_;
};

struct HeapEntry {
  std::string key;
  size_t rank;
  std::unique_ptr<MergeSource> source;
};

// Same min-heap-by-key convention as compaction.cc: reports a as "less
// than" b whenever a's key is larger, so std::make_heap/push_heap/pop_heap
// (a max-heap by default) puts the smallest key at heap.front().
bool HeapLess(const HeapEntry& a, const HeapEntry& b) { return a.key > b.key; }

}  // namespace

std::unique_ptr<MergeSource> MakeMemTableSource(MemTable::Iterator it) {
  return std::make_unique<MemTableSource>(std::move(it));
}

std::unique_ptr<MergeSource> MakeSSTableSource(SSTableReader::Iterator it) {
  return std::make_unique<SSTableSource>(std::move(it));
}

struct MergeIterator::Impl {
  std::vector<HeapEntry> heap;
  bool valid = false;
  std::string key;
  std::string value;

  void Advance() {
    while (!heap.empty()) {
      std::pop_heap(heap.begin(), heap.end(), HeapLess);
      HeapEntry top = std::move(heap.back());
      heap.pop_back();

      std::string cur_key = top.key;
      size_t best_rank = top.rank;
      SSTRecord best_record = top.source->record();

      std::vector<HeapEntry> same_key;
      same_key.push_back(std::move(top));

      // Every other source currently sitting on the same key must be
      // advanced too (deduped); the newest-ranked one wins.
      while (!heap.empty() && heap.front().key == cur_key) {
        std::pop_heap(heap.begin(), heap.end(), HeapLess);
        HeapEntry e = std::move(heap.back());
        heap.pop_back();
        if (e.rank > best_rank) {
          best_rank = e.rank;
          best_record = e.source->record();
        }
        same_key.push_back(std::move(e));
      }

      for (auto& e : same_key) {
        e.source->Next();
        if (e.source->Valid()) {
          HeapEntry next{e.source->key(), e.rank, std::move(e.source)};
          heap.push_back(std::move(next));
          std::push_heap(heap.begin(), heap.end(), HeapLess);
        }
      }

      if (!best_record.deleted) {
        key = cur_key;
        value = std::move(best_record.value);
        valid = true;
        return;
      }
      // Winning record is a tombstone: skip it, keep advancing to the
      // next distinct key instead of stopping here.
    }
    valid = false;
  }
};

MergeIterator::MergeIterator(std::vector<std::unique_ptr<MergeSource>> sources) {
  impl_ = std::make_unique<Impl>();
  size_t rank = 0;
  for (auto& s : sources) {
    if (s->Valid()) {
      HeapEntry e{s->key(), rank, std::move(s)};
      impl_->heap.push_back(std::move(e));
    }
    ++rank;
  }
  std::make_heap(impl_->heap.begin(), impl_->heap.end(), HeapLess);
  impl_->Advance();
}

MergeIterator::~MergeIterator() = default;
MergeIterator::MergeIterator(MergeIterator&&) noexcept = default;
MergeIterator& MergeIterator::operator=(MergeIterator&&) noexcept = default;

bool MergeIterator::Valid() const { return impl_->valid; }
void MergeIterator::Next() { impl_->Advance(); }
const std::string& MergeIterator::key() const { return impl_->key; }
const std::string& MergeIterator::value() const { return impl_->value; }

}  // namespace ministore
