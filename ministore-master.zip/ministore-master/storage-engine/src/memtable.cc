#include "memtable.h"

namespace ministore {

void MemTable::Put(const std::string& key, const std::string& value) {
  auto it = table_.find(key);
  if (it != table_.end()) {
    approx_bytes_ -= it->second.value.size();
  } else {
    approx_bytes_ += key.size();
  }
  approx_bytes_ += value.size();
  table_[key] = Record{value, false};
}

void MemTable::Delete(const std::string& key) {
  auto it = table_.find(key);
  if (it != table_.end()) {
    approx_bytes_ -= it->second.value.size();
    it->second.value.clear();
    it->second.deleted = true;
  } else {
    approx_bytes_ += key.size();
    table_[key] = Record{"", true};
  }
}

bool MemTable::Get(const std::string& key, std::string* value_out, bool* deleted_out) const {
  auto it = table_.find(key);
  if (it == table_.end()) return false;
  *deleted_out = it->second.deleted;
  *value_out = it->second.value;
  return true;
}

void MemTable::Clear() {
  table_.clear();
  approx_bytes_ = 0;
}

}  // namespace ministore
