#pragma once

#include <memory>
#include <string>
#include <vector>

#include "memtable.h"
#include "sstable.h"

namespace ministore {

// Common interface so MergeIterator can heap-merge a MemTable::Iterator
// alongside any number of SSTableReader::Iterators despite those being
// distinct concrete types.
class MergeSource {
 public:
  virtual ~MergeSource() = default;
  virtual bool Valid() const = 0;
  virtual void Next() = 0;
  virtual const std::string& key() const = 0;
  virtual SSTRecord record() const = 0;
};

std::unique_ptr<MergeSource> MakeMemTableSource(MemTable::Iterator it);
std::unique_ptr<MergeSource> MakeSSTableSource(SSTableReader::Iterator it);

// Merges any number of ranked sources into one sorted, deduped,
// tombstone-free forward iteration -- the read path behind Engine::Scan.
// Structurally the same k-way-merge-by-key approach as CompactAll
// (compaction.h), just against a live memtable too and without writing
// output.
//
// `sources` must be ordered oldest-to-newest by rank (index 0 = oldest);
// ties are broken in favor of the highest-ranked (newest) source, and a
// key whose winning record is a tombstone is skipped entirely.
class MergeIterator {
 public:
  explicit MergeIterator(std::vector<std::unique_ptr<MergeSource>> sources);
  ~MergeIterator();
  MergeIterator(MergeIterator&&) noexcept;
  MergeIterator& operator=(MergeIterator&&) noexcept;
  MergeIterator(const MergeIterator&) = delete;
  MergeIterator& operator=(const MergeIterator&) = delete;

  bool Valid() const;
  void Next();
  const std::string& key() const;
  const std::string& value() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace ministore
