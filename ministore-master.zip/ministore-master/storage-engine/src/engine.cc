#include "engine.h"

#include <algorithm>
#include <cstdio>
#include <filesystem>
#include <optional>
#include <system_error>

#include "compaction.h"
#include "merge_iterator.h"

namespace ministore {

namespace fs = std::filesystem;

Engine::Engine(std::string data_dir, size_t memtable_flush_bytes)
    : data_dir_(std::move(data_dir)), memtable_flush_bytes_(memtable_flush_bytes) {
  fs::create_directories(data_dir_);

  // Recover existing SSTables (sorted by filename == flush order), then
  // replay the WAL on top so the memtable matches pre-crash state.
  std::vector<std::string> sstable_paths;
  for (const auto& entry : fs::directory_iterator(data_dir_)) {
    if (entry.path().extension() == ".sst") {
      sstable_paths.push_back(entry.path().string());
    }
  }
  std::sort(sstable_paths.begin(), sstable_paths.end());
  for (auto& p : sstable_paths) {
    sstables_.push_back(std::make_shared<SSTableReader>(p));
  }
  next_sstable_id_.store(static_cast<int>(sstable_paths.size()));

  wal_ = std::make_unique<Wal>((fs::path(data_dir_) / "wal.log").string());
  wal_->Replay([this](const std::string& k, const std::string& v) { memtable_.Put(k, v); },
               [this](const std::string& k) { memtable_.Delete(k); });

  compaction_thread_ = std::thread(&Engine::CompactionThreadMain, this);
}

Engine::~Engine() {
  {
    std::lock_guard<std::mutex> lock(compaction_mu_);
    stop_ = true;
  }
  compaction_cv_.notify_all();
  if (compaction_thread_.joinable()) compaction_thread_.join();
}

std::string Engine::NextSSTablePath() {
  int id = next_sstable_id_.fetch_add(1);
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%06d.sst", id);
  return (fs::path(data_dir_) / buf).string();
}

bool Engine::Put(const std::string& key, const std::string& value) {
  std::lock_guard<std::mutex> lock(mu_);
  if (!wal_->AppendPut(key, value)) return false;
  memtable_.Put(key, value);
  ++write_ops_;
  return MaybeFlush();
}

bool Engine::Delete(const std::string& key) {
  std::lock_guard<std::mutex> lock(mu_);
  if (!wal_->AppendDelete(key)) return false;
  memtable_.Delete(key);
  ++write_ops_;
  return MaybeFlush();
}

bool Engine::Get(const std::string& key, std::string* value_out) {
  std::lock_guard<std::mutex> lock(mu_);
  ++read_ops_;

  bool deleted = false;
  if (memtable_.Get(key, value_out, &deleted)) {
    return !deleted;
  }

  for (auto it = sstables_.rbegin(); it != sstables_.rend(); ++it) {
    if ((*it)->Get(key, value_out, &deleted)) {
      return !deleted;
    }
  }
  return false;
}

bool Engine::Scan(const std::string& start_key, const std::string& end_key,
                   const std::function<void(const std::string&, const std::string&)>& callback) {
  std::vector<std::shared_ptr<SSTableReader>> tables_snapshot;
  std::optional<MemTable::Iterator> mem_it;
  {
    std::lock_guard<std::mutex> lock(mu_);
    ++read_ops_;
    tables_snapshot = sstables_;  // shared_ptr copies: cheap, keeps files alive
    mem_it = memtable_.NewIterator(start_key);
  }

  // Everything below runs outside mu_: SSTables oldest-to-newest first
  // (ranks 0..N-1), memtable last so it gets the highest rank and wins
  // ties, matching MergeIterator's ranking convention.
  std::vector<std::unique_ptr<MergeSource>> sources;
  sources.reserve(tables_snapshot.size() + 1);
  for (auto& t : tables_snapshot) {
    sources.push_back(MakeSSTableSource(t->NewIterator(start_key)));
  }
  sources.push_back(MakeMemTableSource(std::move(*mem_it)));

  MergeIterator merged(std::move(sources));
  while (merged.Valid() && (end_key.empty() || merged.key() < end_key)) {
    callback(merged.key(), merged.value());
    merged.Next();
  }
  return true;
}

bool Engine::MaybeFlush(bool force) {
  if (memtable_.Size() == 0) return true;
  if (!force && memtable_.ApproxBytes() < memtable_flush_bytes_) return true;

  std::vector<std::pair<std::string, SSTRecord>> entries;
  entries.reserve(memtable_.Size());
  for (const auto& kv : memtable_.Entries()) {
    entries.emplace_back(kv.first, SSTRecord{kv.second.value, kv.second.deleted});
  }

  std::string path = NextSSTablePath();
  SSTableWriter writer(path);
  if (!writer.Write(entries)) return false;

  sstables_.push_back(std::make_shared<SSTableReader>(path));
  memtable_.Clear();
  wal_->Reset();

  if (sstables_.size() >= kCompactionTrigger) {
    std::lock_guard<std::mutex> lock(compaction_mu_);
    compaction_requested_ = true;
    compaction_cv_.notify_all();
  }
  return true;
}

void Engine::CompactionThreadMain() {
  while (true) {
    bool force;
    uint64_t seq_being_serviced;
    {
      std::unique_lock<std::mutex> lock(compaction_mu_);
      compaction_cv_.wait(lock, [this] { return stop_ || compaction_requested_; });
      if (stop_) return;
      compaction_requested_ = false;
      force = compaction_force_;
      compaction_force_ = false;
      // Whatever request(s) are pending as of right now are about to be
      // covered by this pass, since it processes the full current
      // sstables_ list regardless of which specific request woke it.
      seq_being_serviced = compaction_request_seq_;
    }

    RunCompactionPass(force);

    {
      std::lock_guard<std::mutex> lock(compaction_mu_);
      compaction_completed_seq_ = seq_being_serviced;
    }
    compaction_cv_.notify_all();
  }
}

void Engine::RunCompactionPass(bool force) {
  std::vector<std::shared_ptr<SSTableReader>> snapshot;
  {
    std::lock_guard<std::mutex> lock(mu_);
    if (sstables_.empty()) return;
    if (!force && sstables_.size() < kCompactionTrigger) return;
    snapshot = sstables_;  // shared_ptr copies: cheap, keeps files alive for any in-flight Get()
  }

  std::string out_path = NextSSTablePath();
  if (!CompactAll(snapshot, out_path)) return;

  auto compacted = std::make_shared<SSTableReader>(out_path);
  if (!compacted->Valid()) return;

  {
    std::lock_guard<std::mutex> lock(mu_);

    // Drop exactly the tables that went into `snapshot` (a prefix of
    // sstables_ as of when the snapshot was taken -- flushes only ever
    // append, and only one compaction pass runs at a time), keep anything
    // flushed since, and put the compacted table at the front since it
    // now represents the oldest data.
    std::vector<std::shared_ptr<SSTableReader>> remaining;
    remaining.reserve(sstables_.size());
    size_t snapshot_idx = 0;
    for (auto& t : sstables_) {
      if (snapshot_idx < snapshot.size() && t == snapshot[snapshot_idx]) {
        ++snapshot_idx;
        continue;
      }
      remaining.push_back(t);
    }

    std::vector<std::shared_ptr<SSTableReader>> new_list;
    new_list.reserve(remaining.size() + 1);
    new_list.push_back(compacted);
    for (auto& t : remaining) new_list.push_back(t);
    sstables_ = std::move(new_list);

    // The compacted table is already a full, deduped, tombstone-free scan
    // of everything folded into this pass -- re-derive exact counts from
    // it directly rather than threading extra state out of CompactAll.
    uint64_t count = 0, bytes = 0;
    for (auto it = compacted->NewIterator(); it.Valid(); it.Next()) {
      ++count;
      bytes += it.key().size() + it.record().value.size();
    }
    compacted_key_count_ = count;
    compacted_bytes_ = bytes;
  }

  for (auto& t : snapshot) {
    std::error_code ec;
    fs::remove(t->path(), ec);
  }
}

void Engine::FlushForTest() {
  std::lock_guard<std::mutex> lock(mu_);
  MaybeFlush(/*force=*/true);
}

void Engine::TriggerCompactionForTest() {
  std::unique_lock<std::mutex> lock(compaction_mu_);
  uint64_t my_seq = ++compaction_request_seq_;
  compaction_requested_ = true;
  compaction_force_ = true;
  compaction_cv_.notify_all();
  compaction_cv_.wait(lock, [this, my_seq] { return compaction_completed_seq_ >= my_seq; });
}

EngineStats Engine::Stats() const {
  std::lock_guard<std::mutex> lock(mu_);
  EngineStats stats;
  // Exact for the compacted majority of the dataset. Anything flushed to a
  // not-yet-compacted SSTable since the last pass isn't counted at all,
  // and a key present in both the memtable and the compacted table is
  // double-counted -- see the field comments in engine.h.
  stats.key_count = compacted_key_count_ + memtable_.Size();
  stats.bytes_stored = compacted_bytes_ + memtable_.ApproxBytes();
  stats.read_ops = read_ops_;
  stats.write_ops = write_ops_;
  return stats;
}

}  // namespace ministore
