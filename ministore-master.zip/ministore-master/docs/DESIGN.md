# ministore — design notes

A small distributed KV database: a C++ LSM-lite storage engine (data
plane), a Go control plane (cluster membership, consistent-hash shard
routing, billing), and a terminal dashboard. Built to develop real depth
in C++ and Go database/cloud-services work. See `README.md` for setup and
`docker-compose.yml` for the multi-node deployment shape.

## Architecture

```
        minictl (Go, terminal UI)
              |  gRPC (control.proto)
              v
     control plane (Go) -- single process, single ingress point
       - consistent-hash shard ring (tenant_id -> owning node)
       - node registry + reaper (evicts unhealthy nodes, self-heals
         on a fresh heartbeat)
       - per-tenant billing meter
              |  gRPC (storage.proto), routed per tenant
              v
   storage node A       storage node B       storage node C
   (C++ engine,          (C++ engine,          (C++ engine,
    own WAL+SSTables)     own WAL+SSTables)     own WAL+SSTables)
```

Each storage node is a single-node LSM-lite engine: writes land in a
sorted in-memory memtable (after an fsync'd WAL append for durability);
once the memtable crosses a size threshold it flushes to an immutable,
sorted SSTable file with a sparse index and a Bloom filter. A background
thread compacts accumulated SSTables into one once they cross a count
threshold, deduplicating keys and dropping tombstones.

Keys are namespaced per tenant at the gRPC boundary
(`tenant_id + '\0' + key`), so the engine itself stays tenant-agnostic;
all multi-tenancy and billing logic lives in the control plane, which
sees every request as it routes it.

## Design decisions and tradeoffs

**Size-tiered compaction, not leveled.** Leveled compaction (LevelDB/
RocksDB-style: per-level key-range non-overlap, level metadata, a
manifest file, compaction-picking heuristics) gives better read/space
amplification but is its own multi-week subsystem. Size-tiered ("merge
every currently-live SSTable into one past a count threshold") is
dramatically simpler, fits the engine's existing flush model with one new
trigger condition, and still demonstrates the core mechanism (a real
k-way merge-sort over sorted runs, tombstone GC) — chosen deliberately for
implementation-risk reasons given the project's timeline, not because it's
the better algorithm in general.

**`shared_ptr<SSTableReader>` for safe concurrent compaction, not a
`std::shared_mutex` upgrade.** The engine still serializes Put/Get/Delete
behind one `std::mutex`. What compaction actually needed wasn't a lock
upgrade — it was for the expensive merge-sort I/O to run with *no lock
held at all*, so it doesn't add latency to concurrent Put/Get calls, while
still being safe if compaction swaps out the SSTable list mid-read. Making
`sstables_` a vector of `shared_ptr` rather than `unique_ptr` gets that:
an in-flight `Get()`/`Scan()` that already grabbed its own copies keeps
reading valid, un-deleted files even after compaction replaces the list
out from under `sstables_`. This is the same reference-counted "Version"
technique RocksDB uses. Verified race-free under ThreadSanitizer.

**Hand-rolled Bloom filter, not a library.** A correct Bloom filter is
~100 lines; pulling in a C++ library would be another manually-installed
dependency on top of an already-fiddly protobuf/gRPC toolchain, for a
component simple enough to just write. Sized at 10 bits/key, k=7 hash
probes derived from two FNV-1a hashes via the Kirsch–Mitzenmacher
combination. Building this surfaced a real bug worth naming: the initial
version measured a ~3.4% false-positive rate against a ~0.83% theoretical
target (40+ standard errors off — not noise) because raw FNV-1a has weak
avalanche in its low bits, exactly the bits the modulo-indexing step is
most sensitive to. Adding a murmur3-style finalizing mix step fixed it to
0.8%, in line with theory.

**Real `fsync`-backed WAL, not `ofstream::flush()`.** The original WAL
used `std::ofstream::flush()`, which only pushes writes to the OS page
cache — enough for process-crash safety, not power-loss durability. The
WAL now uses POSIX `open`/`write`/`fsync` directly and calls `fsync` after
every record. This is deliberately not batched (group-commit is an
explicit backlog item): correctness over throughput for this pass, and
the cost is visible in the benchmarks below.

**Storage-node eviction only changes future routing — it does not migrate
data.** There's no replication in this build (explicit backlog item). The
reaper marks an unhealthy node evicted and removes it from the shard ring
so *future* writes route elsewhere, but that node's already-written shard
is simply unreachable until it comes back. This was worth stating plainly
rather than glossing over, since it's exactly the gap that motivates
adding replication as the next real step.

**Container `GOTOOLCHAIN=local` bit us, not our own version choices.**
`go install .../protoc-gen-go@latest` failed inside the `golang:1.23`
Docker image with "requires go >= 1.23" even after bumping the base image
version to work around it — the actual root cause was that the official
`golang` Docker images set `GOTOOLCHAIN=local`, which blocks Go's normal
"auto-download whatever newer toolchain a tool needs" behavior that made
the identical command succeed on a dev host with `GOTOOLCHAIN=auto`.
Fixed by setting `GOTOOLCHAIN=auto` explicitly in the Dockerfile rather
than chasing pinned plugin versions that would just go stale as new
releases bump their own requirements.

## Benchmarks

All numbers from this machine (single dev box, not a controlled bench
environment) — meant to show real, measured before/after deltas and their
size, not to be taken as absolute performance claims.

### Compaction: present-key Get latency, 20 accumulated SSTables vs. 1

`storage-engine/tools/bench_compaction.cc` builds 20 non-overlapping
40,000-key SSTables directly (bypassing `Engine`, so its own automatic
compaction trigger doesn't interfere), measures average Get latency
across all 20 the way `Engine::Get`'s SSTable fallback loop does, then
compacts them into one via `CompactAll` and re-measures.

```
BEFORE compaction (20 tables): avg 16-20 us/lookup
AFTER  compaction (1 table):   avg  7-16 us/lookup
Speedup: 1.1x-2.5x across repeated runs
```

The range is wide — this is sensitive to OS page-cache state across 20
files vs. 1 (a cold vs. warm cache changes the picture a lot at this
scale), worth reporting honestly as a range rather than the single
best-looking number.

### Bloom filter: missing-key lookup latency, with vs. without

Same 20-table setup, comparing `SSTableReader::Get()` (Bloom filter
active) against a raw index-seek-and-scan via `NewIterator(key)` — the
same sparse-index path `Get()` falls back to on a possible match, but
without the `MightContain()` short-circuit, i.e. what every miss would
cost with no Bloom filter at all.

```
WITH bloom filter:    avg 2.2-2.4 us/lookup
WITHOUT bloom filter: avg ~80 us/lookup
Speedup: 33x-37x
```

This is the clean, expected result: Bloom filters specifically help
*missing*-key lookups (the case a present-key Get can't skip — the value
still has to be read either way), and the win is large because it avoids
the seek-and-scan entirely rather than just making it faster.

### Load test: 1-node vs. 3-node, moderate load (300 req/s target)

`control-plane/cmd/loadgen` is an open-loop generator (Poisson
inter-arrival, not closed-loop, so it doesn't self-throttle and hide tail
latency) against the real Docker Compose cluster.

```
1 node:  296.7 ops/sec, p50=4.1ms  p95=11.9ms  p99=21.4ms  errors=0
3 nodes: 294.6 ops/sec, p50=3.6ms  p95=10.4ms  p99=23.2ms  errors=0
```

Nearly identical — at this load, neither configuration is actually
saturated, so the extra storage-tier capacity doesn't show up yet.

### Load test: 1-node vs. 3-node, higher load (700 req/s target)

```
1 node:  694.7 ops/sec, p50=8.1ms  p95=803ms   p99=1054ms  errors=0
3 nodes: 706.1 ops/sec, p50=5.3ms  p95=737ms   p99=1057ms  errors=0
```

This is the more interesting result, and not the one a "more nodes is
just faster" intuition would predict: p95/p99 latency degrades sharply in
*both* configurations, by almost the same amount. That points at the
control plane itself, not storage-node fan-out capacity, as the actual
bottleneck at this load — specifically `storageClient()` in
`cmd/controlplane/main.go`, which dials a **fresh gRPC connection per
request** with no pooling. At 700 req/s that's up to 700 new TCP
connections/sec funneling through one process regardless of how many
storage nodes exist behind it, which matches exactly what was already
flagged as a known inefficiency in Week 4's own code review, now
confirmed empirically rather than just asserted. An even higher test
(1500 req/s against a single node) made this concrete: 82% of requests
started timing out, consistent with genuine resource exhaustion (ephemeral
ports/file descriptors) from the per-request dial pattern, not gradual
degradation.

**Takeaway**: horizontally scaling the storage tier doesn't help until
the control plane's own ingress path stops being the bottleneck — the
README's "the control plane is still a single ingress point in this
design" caveat is a benchmarked finding, not just a stated assumption.
Connection pooling in `storageClient()` is the natural next fix, tracked
in the backlog.

## Backlog (not attempted in this pass)

Replication/HA, per-tenant auth/rate limiting, Prometheus metrics,
Kubernetes manifests, group-commit WAL batching, gRPC connection pooling
in the control plane, TLS, and a SQL-lite query layer.
