package billing

import "testing"

func TestMeterAccumulatesPerTenant(t *testing.T) {
	m := NewMeter()
	m.RecordRead("tenant-a")
	m.RecordRead("tenant-a")
	m.RecordWrite("tenant-a")
	m.RecordRead("tenant-b")
	m.SetBytesStored("tenant-a", 1<<20)

	a := m.Get("tenant-a")
	if a.ReadOps != 2 || a.WriteOps != 1 || a.BytesStored != 1<<20 {
		t.Fatalf("unexpected usage for tenant-a: %+v", a)
	}

	b := m.Get("tenant-b")
	if b.ReadOps != 1 || b.WriteOps != 0 {
		t.Fatalf("unexpected usage for tenant-b: %+v", b)
	}

	if len(m.List()) != 2 {
		t.Fatalf("expected 2 tenants tracked, got %d", len(m.List()))
	}
}

func TestEstimatedCostIsMonotonic(t *testing.T) {
	base := Usage{TenantID: "t", ReadOps: 100, WriteOps: 10, BytesStored: 1 << 20}
	more := base
	more.WriteOps += 100

	if more.EstimatedCostUSD() <= base.EstimatedCostUSD() {
		t.Fatalf("expected cost to increase with more writes: base=%f more=%f",
			base.EstimatedCostUSD(), more.EstimatedCostUSD())
	}
}
