// Package billing meters per-tenant read/write operations and storage
// bytes as the control plane routes requests, and derives an estimated
// cost -- the same usage-to-cost shape as a real cloud billing service,
// with flat per-unit constants standing in for a real pricing table.
package billing

import "sync"

const (
	costPerReadOp  = 0.0000004 // $ per read
	costPerWriteOp = 0.0000012 // $ per write (costlier: WAL fsync + eventual compaction)
	costPerGBMonth = 0.023     // $ per GB-month stored, ballpark S3-standard-like rate
)

type Usage struct {
	TenantID    string
	BytesStored uint64
	ReadOps     uint64
	WriteOps    uint64
}

func (u Usage) EstimatedCostUSD() float64 {
	storageGB := float64(u.BytesStored) / (1 << 30)
	return float64(u.ReadOps)*costPerReadOp +
		float64(u.WriteOps)*costPerWriteOp +
		storageGB*costPerGBMonth
}

// Meter accumulates usage per tenant. The control plane calls RecordRead /
// RecordWrite on every routed request, and SetBytesStored whenever a
// node's heartbeat reports fresh capacity numbers.
type Meter struct {
	mu    sync.Mutex
	usage map[string]*Usage
}

func NewMeter() *Meter {
	return &Meter{usage: make(map[string]*Usage)}
}

// get must be called with mu held.
func (m *Meter) get(tenantID string) *Usage {
	u, ok := m.usage[tenantID]
	if !ok {
		u = &Usage{TenantID: tenantID}
		m.usage[tenantID] = u
	}
	return u
}

func (m *Meter) RecordRead(tenantID string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.get(tenantID).ReadOps++
}

func (m *Meter) RecordWrite(tenantID string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.get(tenantID).WriteOps++
}

func (m *Meter) SetBytesStored(tenantID string, bytes uint64) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.get(tenantID).BytesStored = bytes
}

func (m *Meter) Get(tenantID string) Usage {
	m.mu.Lock()
	defer m.mu.Unlock()
	return *m.get(tenantID)
}

func (m *Meter) List() []Usage {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make([]Usage, 0, len(m.usage))
	for _, u := range m.usage {
		out = append(out, *u)
	}
	return out
}
