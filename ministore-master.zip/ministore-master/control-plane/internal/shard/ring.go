// Package shard implements a consistent-hashing ring that maps tenant ids
// to storage nodes, so the control plane can route requests and rebalance
// ownership when nodes join or leave without reshuffling every key.
package shard

import (
	"crypto/sha1"
	"encoding/binary"
	"sort"
	"strconv"
	"sync"
)

const defaultVirtualNodes = 100

// Ring is safe for concurrent use.
type Ring struct {
	mu           sync.RWMutex
	virtualNodes int
	hashToNode   map[uint32]string
	sortedHashes []uint32
	nodes        map[string]bool
}

func NewRing(virtualNodes int) *Ring {
	if virtualNodes <= 0 {
		virtualNodes = defaultVirtualNodes
	}
	return &Ring{
		virtualNodes: virtualNodes,
		hashToNode:   make(map[uint32]string),
		nodes:        make(map[string]bool),
	}
}

func hashKey(s string) uint32 {
	sum := sha1.Sum([]byte(s))
	return binary.BigEndian.Uint32(sum[:4])
}

// AddNode inserts a node's virtual replicas into the ring. Adding a node
// only remaps the keys whose ring position now falls before one of its new
// virtual nodes, not the whole keyspace.
func (r *Ring) AddNode(nodeID string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.nodes[nodeID] {
		return
	}
	r.nodes[nodeID] = true
	for i := 0; i < r.virtualNodes; i++ {
		h := hashKey(nodeID + "#" + strconv.Itoa(i))
		r.hashToNode[h] = nodeID
	}
	r.rebuildSorted()
}

func (r *Ring) RemoveNode(nodeID string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if !r.nodes[nodeID] {
		return
	}
	delete(r.nodes, nodeID)
	for i := 0; i < r.virtualNodes; i++ {
		h := hashKey(nodeID + "#" + strconv.Itoa(i))
		delete(r.hashToNode, h)
	}
	r.rebuildSorted()
}

// Owner returns the node responsible for key, or "" if the ring is empty.
func (r *Ring) Owner(key string) string {
	r.mu.RLock()
	defer r.mu.RUnlock()
	if len(r.sortedHashes) == 0 {
		return ""
	}
	h := hashKey(key)
	idx := sort.Search(len(r.sortedHashes), func(i int) bool { return r.sortedHashes[i] >= h })
	if idx == len(r.sortedHashes) {
		idx = 0
	}
	return r.hashToNode[r.sortedHashes[idx]]
}

func (r *Ring) Nodes() []string {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]string, 0, len(r.nodes))
	for n := range r.nodes {
		out = append(out, n)
	}
	sort.Strings(out)
	return out
}

// rebuildSorted must be called with mu_ held.
func (r *Ring) rebuildSorted() {
	sorted := make([]uint32, 0, len(r.hashToNode))
	for h := range r.hashToNode {
		sorted = append(sorted, h)
	}
	sort.Slice(sorted, func(i, j int) bool { return sorted[i] < sorted[j] })
	r.sortedHashes = sorted
}
