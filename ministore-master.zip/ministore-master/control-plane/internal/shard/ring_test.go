package shard

import (
	"fmt"
	"testing"
)

func TestOwnerStableAcrossAdditions(t *testing.T) {
	r := NewRing(100)
	r.AddNode("node-a")
	r.AddNode("node-b")
	r.AddNode("node-c")

	keys := make([]string, 1000)
	before := make(map[string]string, len(keys))
	for i := range keys {
		keys[i] = fmt.Sprintf("tenant-%d", i)
		before[keys[i]] = r.Owner(keys[i])
	}

	r.AddNode("node-d")

	moved := 0
	for _, k := range keys {
		if r.Owner(k) != before[k] {
			moved++
		}
	}

	// Adding a 4th node to a 3-node ring should remap roughly 1/4 of keys,
	// not anywhere close to all of them -- that's the whole point of
	// consistent hashing over naive mod-N hashing.
	if moved > len(keys)/2 {
		t.Fatalf("too many keys remapped on node addition: %d/%d", moved, len(keys))
	}
	if moved == 0 {
		t.Fatalf("expected some keys to move to the new node, got 0")
	}
}

func TestOwnerEmptyRing(t *testing.T) {
	r := NewRing(10)
	if got := r.Owner("anything"); got != "" {
		t.Fatalf("expected empty owner for empty ring, got %q", got)
	}
}

func TestRemoveNode(t *testing.T) {
	r := NewRing(50)
	r.AddNode("a")
	r.AddNode("b")
	r.RemoveNode("a")

	if got := r.Owner("some-key"); got != "b" {
		t.Fatalf("expected sole remaining node b to own all keys, got %q", got)
	}
}
