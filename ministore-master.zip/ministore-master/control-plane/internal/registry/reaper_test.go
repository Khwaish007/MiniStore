package registry

import (
	"context"
	"testing"
	"time"

	"ministore/internal/shard"
)

func TestReaperEvictsUnhealthyNode(t *testing.T) {
	// Short healthy window so this test doesn't wait out the real 15s
	// default.
	reg := NewWithHealthyWindow(20 * time.Millisecond)
	ring := shard.NewRing(10)

	reg.Register("dead-node", "localhost:9999")
	ring.AddNode("dead-node")
	reg.Register("alive-node", "localhost:9998")
	ring.AddNode("alive-node")

	var evicted []string
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go reg.StartReaper(ctx, ring, 10*time.Millisecond, func(nodeID string) {
		evicted = append(evicted, nodeID)
	})

	// Keep "alive-node" heartbeating throughout so it never crosses the
	// healthy window, while "dead-node" never heartbeats again after
	// Register and should get evicted.
	deadline := time.Now().Add(200 * time.Millisecond)
	for time.Now().Before(deadline) {
		reg.Heartbeat("alive-node", 0, 0)
		time.Sleep(5 * time.Millisecond)
	}

	n, ok := reg.Get("dead-node")
	if !ok || !n.Evicted {
		t.Fatalf("expected dead-node to be evicted, got %+v (ok=%v)", n, ok)
	}
	a, ok := reg.Get("alive-node")
	if !ok || a.Evicted {
		t.Fatalf("expected alive-node to stay healthy/not evicted, got %+v (ok=%v)", a, ok)
	}

	found := false
	for _, id := range evicted {
		if id == "dead-node" {
			found = true
		}
		if id == "alive-node" {
			t.Fatalf("alive-node should never have been evicted")
		}
	}
	if !found {
		t.Fatalf("onEvict callback was never invoked for dead-node")
	}

	ringNodes := ring.Nodes()
	for _, id := range ringNodes {
		if id == "dead-node" {
			t.Fatalf("dead-node should have been removed from the ring, still present: %v", ringNodes)
		}
	}
}

func TestHeartbeatSelfHealsEviction(t *testing.T) {
	reg := NewWithHealthyWindow(20 * time.Millisecond)
	reg.Register("flaky-node", "localhost:9997")

	if !reg.Evict("flaky-node") {
		t.Fatalf("expected Evict to succeed on a known node")
	}
	n, _ := reg.Get("flaky-node")
	if !n.Evicted {
		t.Fatalf("expected flaky-node to be evicted")
	}

	reg.Heartbeat("flaky-node", 1, 1)
	n, _ = reg.Get("flaky-node")
	if n.Evicted {
		t.Fatalf("expected a fresh heartbeat to clear the eviction flag")
	}
}
