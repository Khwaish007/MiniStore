// Package registry tracks storage-node membership and liveness for the
// control plane: which nodes exist, their last heartbeat, and the capacity
// numbers each heartbeat reports.
package registry

import (
	"sync"
	"time"
)

// defaultHealthyWindow is how long a node can go without a heartbeat
// before it's reported unhealthy in cluster status.
const defaultHealthyWindow = 15 * time.Second

type NodeInfo struct {
	NodeID        string
	Address       string
	KeyCount      uint64
	BytesStored   uint64
	LastHeartbeat time.Time
	// Evicted marks a node the reaper has removed from the shard ring for
	// being unhealthy. It's a flag rather than a deletion so ClusterStatus
	// can keep showing a "recently died" node for operator visibility
	// instead of it silently vanishing.
	Evicted   bool
	EvictedAt time.Time
}

// Registry is safe for concurrent use.
type Registry struct {
	mu            sync.RWMutex
	nodes         map[string]*NodeInfo
	healthyWindow time.Duration
}

func New() *Registry {
	return NewWithHealthyWindow(defaultHealthyWindow)
}

// NewWithHealthyWindow is New with an explicit healthy window -- mainly
// for tests that don't want to wait out the real default.
func NewWithHealthyWindow(healthyWindow time.Duration) *Registry {
	return &Registry{nodes: make(map[string]*NodeInfo), healthyWindow: healthyWindow}
}

func (r *Registry) Register(nodeID, address string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.nodes[nodeID] = &NodeInfo{NodeID: nodeID, Address: address, LastHeartbeat: time.Now()}
}

// Heartbeat clears a prior eviction on the node it updates -- receiving a
// heartbeat is proof of life regardless of whether the reaper previously
// gave up on it (e.g. after a transient network blip), so a node that
// keeps heartbeating self-heals back to healthy on its own. The caller is
// still responsible for re-adding the node to the shard ring; see
// StartReaper's onEvict/re-add wiring in cmd/controlplane.
func (r *Registry) Heartbeat(nodeID string, keyCount, bytesStored uint64) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	n, ok := r.nodes[nodeID]
	if !ok {
		return false
	}
	n.KeyCount = keyCount
	n.BytesStored = bytesStored
	n.LastHeartbeat = time.Now()
	n.Evicted = false
	return true
}

// Evict marks a node evicted (see NodeInfo.Evicted). Returns false if the
// node is unknown or already evicted, so callers only act on a real
// state transition (e.g. only removing it from the ring once).
func (r *Registry) Evict(nodeID string) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	n, ok := r.nodes[nodeID]
	if !ok || n.Evicted {
		return false
	}
	n.Evicted = true
	n.EvictedAt = time.Now()
	return true
}

func (r *Registry) Get(nodeID string) (*NodeInfo, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	n, ok := r.nodes[nodeID]
	if !ok {
		return nil, false
	}
	cp := *n
	return &cp, true
}

func (r *Registry) List() []*NodeInfo {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]*NodeInfo, 0, len(r.nodes))
	for _, n := range r.nodes {
		cp := *n
		out = append(out, &cp)
	}
	return out
}

func (r *Registry) IsHealthy(n *NodeInfo) bool {
	return time.Since(n.LastHeartbeat) < r.healthyWindow
}
