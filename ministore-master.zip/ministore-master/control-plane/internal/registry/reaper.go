package registry

import (
	"context"
	"time"

	"ministore/internal/shard"
)

// StartReaper runs until ctx is done, checking node health every interval
// and evicting any unhealthy, not-yet-evicted node from ring. onEvict (if
// non-nil) is called once per node the moment it's evicted -- callers use
// this for logging.
//
// Eviction only changes *future write routing*. It does not migrate the
// evicted node's on-disk data anywhere -- there is no replication in this
// build (see the project backlog) -- so that node's shard is simply
// unreachable for both reads and writes until it comes back and starts
// heartbeating again (which self-heals it via Registry.Heartbeat).
func (r *Registry) StartReaper(ctx context.Context, ring *shard.Ring, interval time.Duration,
	onEvict func(nodeID string)) {
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			for _, n := range r.List() {
				if n.Evicted || r.IsHealthy(n) {
					continue
				}
				if r.Evict(n.NodeID) {
					ring.RemoveNode(n.NodeID)
					if onEvict != nil {
						onEvict(n.NodeID)
					}
				}
			}
		}
	}
}
