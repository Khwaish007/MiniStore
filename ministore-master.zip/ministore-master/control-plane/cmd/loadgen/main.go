// Command loadgen is an open-loop load generator against the control
// plane: each worker dispatches requests at a fixed target rate,
// independent of how long previous requests take to complete, using
// Poisson-distributed inter-arrival times. A closed-loop generator (wait
// for a response before issuing the next request) self-throttles to
// whatever the system can keep up with and under-reports tail latency
// under real load -- exactly the failure mode this is built to avoid.
package main

import (
	"context"
	"encoding/csv"
	"flag"
	"fmt"
	"log"
	"math/rand"
	"os"
	"sort"
	"strconv"
	"sync"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	pb "ministore/gen/controlpb"
)

type result struct {
	latency time.Duration
	err     error
	isRead  bool
}

func keyFor(i int) string { return fmt.Sprintf("key-%08d", i) }

func main() {
	addr := flag.String("control", "localhost:8080", "control-plane address")
	workers := flag.Int("workers", 8, "number of concurrent dispatcher goroutines")
	rate := flag.Float64("rate", 200, "target requests/sec, total across all workers")
	duration := flag.Duration("duration", 10*time.Second, "how long to generate load")
	keySpace := flag.Int("key-space", 2000, "distinct keys per tenant")
	valueSize := flag.Int("value-size", 64, "value size in bytes")
	readRatio := flag.Float64("read-ratio", 0.8, "fraction of requests that are reads (rest are writes)")
	tenantCount := flag.Int("tenants", 4, "number of distinct tenants to spread load across")
	seedWorkers := flag.Int("seed-workers", 20, "concurrency used only for pre-seeding keys")
	csvPath := flag.String("csv", "", "optional path to write per-request CSV (op,latency_us,ok)")
	flag.Parse()

	conn, err := grpc.Dial(*addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("dial: %v", err)
	}
	defer conn.Close()
	client := pb.NewControlServiceClient(conn)

	value := make([]byte, *valueSize)
	for i := range value {
		value[i] = byte('a' + i%26)
	}

	tenants := make([]string, *tenantCount)
	for i := range tenants {
		tenants[i] = fmt.Sprintf("loadgen-tenant-%d", i)
	}

	seedKeys(client, tenants, *keySpace, value, *seedWorkers)

	resultsCh := make(chan result, 100000)
	var inFlight sync.WaitGroup
	var dispatchWG sync.WaitGroup

	stop := time.Now().Add(*duration)
	perWorkerRate := *rate / float64(*workers)

	for w := 0; w < *workers; w++ {
		dispatchWG.Add(1)
		go func(workerID int) {
			defer dispatchWG.Done()
			rng := rand.New(rand.NewSource(int64(workerID)*7919 + time.Now().UnixNano()))
			for time.Now().Before(stop) {
				// Exponentially distributed gap => Poisson arrival process.
				gapSeconds := rng.ExpFloat64() / perWorkerRate
				time.Sleep(time.Duration(gapSeconds * float64(time.Second)))

				inFlight.Add(1)
				go func() {
					defer inFlight.Done()
					tenant := tenants[rng.Intn(len(tenants))]
					isRead := rng.Float64() < *readRatio
					key := []byte(keyFor(rng.Intn(*keySpace)))

					ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
					defer cancel()

					start := time.Now()
					var opErr error
					if isRead {
						_, opErr = client.Get(ctx, &pb.GetRequest{TenantId: tenant, Key: key})
					} else {
						_, opErr = client.Put(ctx, &pb.PutRequest{TenantId: tenant, Key: key, Value: value})
					}
					resultsCh <- result{latency: time.Since(start), err: opErr, isRead: isRead}
				}()
			}
		}(w)
	}

	dispatchWG.Wait()
	inFlight.Wait()
	close(resultsCh)

	report(resultsCh, *duration, *workers, *rate, *tenantCount, *keySpace, *readRatio, *csvPath)
}

// seedKeys pre-populates every tenant's keyspace so read requests have
// something real to hit instead of measuring 100%-miss latency; run
// concurrently since this is setup, not the thing being measured.
func seedKeys(client pb.ControlServiceClient, tenants []string, keySpace int, value []byte, concurrency int) {
	type job struct {
		tenant string
		index  int
	}
	jobs := make(chan job, concurrency*2)
	var wg sync.WaitGroup

	total := len(tenants) * keySpace
	log.Printf("seeding %d tenants x %d keys (%d total)...", len(tenants), keySpace, total)

	for i := 0; i < concurrency; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range jobs {
				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				_, err := client.Put(ctx, &pb.PutRequest{
					TenantId: j.tenant, Key: []byte(keyFor(j.index)), Value: value,
				})
				cancel()
				if err != nil {
					log.Fatalf("seed put(%s, %d): %v", j.tenant, j.index, err)
				}
			}
		}()
	}

	for _, tenant := range tenants {
		for i := 0; i < keySpace; i++ {
			jobs <- job{tenant: tenant, index: i}
		}
	}
	close(jobs)
	wg.Wait()
	log.Printf("seeding done")
}

func report(resultsCh <-chan result, duration time.Duration, workers int, rate float64,
	tenantCount, keySpace int, readRatio float64, csvPath string) {
	var csvWriter *csv.Writer
	if csvPath != "" {
		f, err := os.Create(csvPath)
		if err != nil {
			log.Fatalf("create csv: %v", err)
		}
		defer f.Close()
		csvWriter = csv.NewWriter(f)
		defer csvWriter.Flush()
		_ = csvWriter.Write([]string{"op", "latency_us", "ok"})
	}

	var latencies []time.Duration
	var errCount, readCount, writeCount int
	for r := range resultsCh {
		latencies = append(latencies, r.latency)
		if r.err != nil {
			errCount++
		}
		if r.isRead {
			readCount++
		} else {
			writeCount++
		}
		if csvWriter != nil {
			op := "write"
			if r.isRead {
				op = "read"
			}
			_ = csvWriter.Write([]string{op, strconv.FormatInt(r.latency.Microseconds(), 10),
				strconv.FormatBool(r.err == nil)})
		}
	}

	sort.Slice(latencies, func(i, j int) bool { return latencies[i] < latencies[j] })
	n := len(latencies)
	pct := func(p float64) time.Duration {
		if n == 0 {
			return 0
		}
		idx := int(p * float64(n))
		if idx >= n {
			idx = n - 1
		}
		return latencies[idx]
	}

	fmt.Printf("\n=== loadgen results ===\n")
	fmt.Printf("duration=%s workers=%d target_rate=%.1f/s tenants=%d key_space=%d read_ratio=%.2f\n",
		duration, workers, rate, tenantCount, keySpace, readRatio)
	fmt.Printf("requests: total=%d reads=%d writes=%d errors=%d\n", n, readCount, writeCount, errCount)
	if n == 0 {
		return
	}
	fmt.Printf("throughput: %.1f ops/sec\n", float64(n)/duration.Seconds())
	fmt.Printf("latency: p50=%v p95=%v p99=%v max=%v\n", pct(0.50), pct(0.95), pct(0.99), latencies[n-1])
}
