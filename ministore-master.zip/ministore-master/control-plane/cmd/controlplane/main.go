// Command controlplane runs the control-plane server: cluster membership,
// consistent-hash shard routing to storage nodes, and per-tenant billing
// metering, all exposed over the control.proto gRPC API that minictl and
// clients talk to.
package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"net"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	pb "ministore/gen/controlpb"
	storagepb "ministore/gen/storagepb"
	"ministore/internal/billing"
	"ministore/internal/registry"
	"ministore/internal/shard"
)

type server struct {
	pb.UnimplementedControlServiceServer

	ring  *shard.Ring
	reg   *registry.Registry
	meter *billing.Meter
}

func newServer() *server {
	return &server{
		ring:  shard.NewRing(100),
		reg:   registry.New(),
		meter: billing.NewMeter(),
	}
}

func (s *server) storageClient(nodeID string) (storagepb.StorageServiceClient, func(), error) {
	n, ok := s.reg.Get(nodeID)
	if !ok {
		return nil, nil, fmt.Errorf("no such node registered: %q", nodeID)
	}
	conn, err := grpc.Dial(n.Address, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, nil, err
	}
	return storagepb.NewStorageServiceClient(conn), func() { conn.Close() }, nil
}

func (s *server) Put(ctx context.Context, req *pb.PutRequest) (*pb.PutResponse, error) {
	client, closeFn, err := s.storageClient(s.ring.Owner(req.TenantId))
	if err != nil {
		return nil, err
	}
	defer closeFn()

	resp, err := client.Put(ctx, &storagepb.PutRequest{
		TenantId: req.TenantId, Key: req.Key, Value: req.Value,
	})
	if err != nil {
		return nil, err
	}
	s.meter.RecordWrite(req.TenantId)
	return &pb.PutResponse{Ok: resp.Ok}, nil
}

func (s *server) Get(ctx context.Context, req *pb.GetRequest) (*pb.GetResponse, error) {
	client, closeFn, err := s.storageClient(s.ring.Owner(req.TenantId))
	if err != nil {
		return nil, err
	}
	defer closeFn()

	resp, err := client.Get(ctx, &storagepb.GetRequest{TenantId: req.TenantId, Key: req.Key})
	if err != nil {
		return nil, err
	}
	s.meter.RecordRead(req.TenantId)
	return &pb.GetResponse{Found: resp.Found, Value: resp.Value}, nil
}

func (s *server) Delete(ctx context.Context, req *pb.DeleteRequest) (*pb.DeleteResponse, error) {
	client, closeFn, err := s.storageClient(s.ring.Owner(req.TenantId))
	if err != nil {
		return nil, err
	}
	defer closeFn()

	resp, err := client.Delete(ctx, &storagepb.DeleteRequest{TenantId: req.TenantId, Key: req.Key})
	if err != nil {
		return nil, err
	}
	s.meter.RecordWrite(req.TenantId)
	return &pb.DeleteResponse{Ok: resp.Ok}, nil
}

func (s *server) RegisterNode(ctx context.Context, req *pb.RegisterNodeRequest) (*pb.RegisterNodeResponse, error) {
	s.reg.Register(req.NodeId, req.Address)
	s.ring.AddNode(req.NodeId)
	return &pb.RegisterNodeResponse{Ok: true, OwnedShards: []string{req.NodeId}}, nil
}

func (s *server) Heartbeat(ctx context.Context, req *pb.HeartbeatRequest) (*pb.HeartbeatResponse, error) {
	ok := s.reg.Heartbeat(req.NodeId, req.KeyCount, req.BytesStored)
	if ok {
		// AddNode is idempotent, so this is a no-op for a node that was
		// never evicted and the self-heal step for one that was: a node
		// that keeps heartbeating gets put back on the ring automatically
		// rather than staying excluded until someone calls RegisterNode again.
		s.ring.AddNode(req.NodeId)
	}
	return &pb.HeartbeatResponse{Ok: ok}, nil
}

func (s *server) ClusterStatus(ctx context.Context, _ *pb.ClusterStatusRequest) (*pb.ClusterStatusResponse, error) {
	resp := &pb.ClusterStatusResponse{}
	for _, n := range s.reg.List() {
		resp.Nodes = append(resp.Nodes, &pb.NodeStatus{
			NodeId:            n.NodeID,
			Address:           n.Address,
			Healthy:           s.reg.IsHealthy(n),
			KeyCount:          n.KeyCount,
			BytesStored:       n.BytesStored,
			LastHeartbeatUnix: n.LastHeartbeat.Unix(),
			Evicted:           n.Evicted,
		})
	}
	return resp, nil
}

func (s *server) GetUsage(ctx context.Context, req *pb.GetUsageRequest) (*pb.GetUsageResponse, error) {
	u := s.meter.Get(req.TenantId)
	return &pb.GetUsageResponse{
		TenantId:         u.TenantID,
		BytesStored:      u.BytesStored,
		ReadOps:          u.ReadOps,
		WriteOps:         u.WriteOps,
		EstimatedCostUsd: u.EstimatedCostUSD(),
	}, nil
}

func (s *server) ListUsage(ctx context.Context, _ *pb.ListUsageRequest) (*pb.ListUsageResponse, error) {
	resp := &pb.ListUsageResponse{}
	for _, u := range s.meter.List() {
		resp.Tenants = append(resp.Tenants, &pb.GetUsageResponse{
			TenantId:         u.TenantID,
			BytesStored:      u.BytesStored,
			ReadOps:          u.ReadOps,
			WriteOps:         u.WriteOps,
			EstimatedCostUsd: u.EstimatedCostUSD(),
		})
	}
	return resp, nil
}

func main() {
	addr := flag.String("addr", ":8080", "control-plane listen address")
	reaperInterval := flag.Duration("reaper-interval", 5*time.Second,
		"how often to check for and evict unhealthy nodes from the shard ring")
	flag.Parse()

	lis, err := net.Listen("tcp", *addr)
	if err != nil {
		log.Fatalf("listen: %v", err)
	}

	srv := newServer()
	grpcServer := grpc.NewServer()
	pb.RegisterControlServiceServer(grpcServer, srv)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go srv.reg.StartReaper(ctx, srv.ring, *reaperInterval, func(nodeID string) {
		log.Printf("evicted unhealthy node %q from the shard ring (no replication in this "+
			"build, so its shard is unreachable until it comes back)", nodeID)
	})

	log.Printf("ministore control plane listening on %s", *addr)
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("serve: %v", err)
	}
}
