// Command minictl is the terminal dashboard for the ministore cluster: it
// polls the control plane over gRPC and renders node health and per-tenant
// billing usage as refreshing text tables. This is the operator-facing
// view for the project -- no web dashboard.
package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"sort"
	"text/tabwriter"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	pb "ministore/gen/controlpb"
)

func main() {
	addr := flag.String("control", "localhost:8080", "control-plane address")
	interval := flag.Duration("interval", 2*time.Second, "refresh interval")
	once := flag.Bool("once", false, "render a single snapshot and exit (no polling)")
	flag.Parse()

	conn, err := grpc.Dial(*addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("dial control plane: %v", err)
	}
	defer conn.Close()
	client := pb.NewControlServiceClient(conn)

	render := func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()

		status, err := client.ClusterStatus(ctx, &pb.ClusterStatusRequest{})
		if err != nil {
			fmt.Printf("error fetching cluster status: %v\n", err)
			return
		}
		usage, err := client.ListUsage(ctx, &pb.ListUsageRequest{})
		if err != nil {
			fmt.Printf("error fetching usage: %v\n", err)
			return
		}

		if !*once {
			fmt.Print("\033[H\033[2J") // clear terminal for a live-refreshing view
		}
		fmt.Printf("ministore cluster -- %s\n\n", time.Now().Format(time.RFC3339))

		fmt.Println("NODES")
		w := tabwriter.NewWriter(os.Stdout, 0, 2, 2, ' ', 0)
		fmt.Fprintln(w, "NODE ID\tADDRESS\tHEALTHY\tEVICTED\tKEYS\tBYTES\tLAST HEARTBEAT")
		nodes := status.Nodes
		sort.Slice(nodes, func(i, j int) bool { return nodes[i].NodeId < nodes[j].NodeId })
		for _, n := range nodes {
			fmt.Fprintf(w, "%s\t%s\t%v\t%v\t%d\t%d\t%s\n",
				n.NodeId, n.Address, n.Healthy, n.Evicted, n.KeyCount, n.BytesStored,
				time.Unix(n.LastHeartbeatUnix, 0).Format(time.RFC3339))
		}
		w.Flush()

		fmt.Println("\nBILLING (per tenant)")
		w2 := tabwriter.NewWriter(os.Stdout, 0, 2, 2, ' ', 0)
		fmt.Fprintln(w2, "TENANT\tREADS\tWRITES\tBYTES STORED\tEST. COST (USD)")
		tenants := usage.Tenants
		sort.Slice(tenants, func(i, j int) bool { return tenants[i].TenantId < tenants[j].TenantId })
		for _, u := range tenants {
			fmt.Fprintf(w2, "%s\t%d\t%d\t%d\t$%.6f\n",
				u.TenantId, u.ReadOps, u.WriteOps, u.BytesStored, u.EstimatedCostUsd)
		}
		w2.Flush()
	}

	render()
	if *once {
		return
	}
	ticker := time.NewTicker(*interval)
	defer ticker.Stop()
	for range ticker.C {
		render()
	}
}
